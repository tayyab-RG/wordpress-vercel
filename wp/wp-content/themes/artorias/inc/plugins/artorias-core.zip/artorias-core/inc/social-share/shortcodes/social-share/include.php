<?php

include_once ARTORIAS_CORE_INC_PATH . '/social-share/shortcodes/social-share/class-artoriascore-social-share-shortcode.php';

foreach ( glob( ARTORIAS_CORE_INC_PATH . '/social-share/shortcodes/social-share/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
