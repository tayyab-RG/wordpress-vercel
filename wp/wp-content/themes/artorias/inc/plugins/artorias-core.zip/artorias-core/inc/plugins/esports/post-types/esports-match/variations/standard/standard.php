<?php

if ( ! function_exists( 'artorias_core_add_esports_match_single_variation_standard' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function artorias_core_add_esports_match_single_variation_standard( $variations ) {
		$variations['standard'] = esc_html__( 'Standard', 'artorias-core' );

		return $variations;
	}

	add_filter( 'artorias_core_filter_esports_match_single_layout_options', 'artorias_core_add_esports_match_single_variation_standard' );
}
