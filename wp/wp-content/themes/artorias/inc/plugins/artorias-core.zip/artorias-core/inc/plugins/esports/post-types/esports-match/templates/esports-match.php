<div class="qodef-grid-item <?php echo esc_attr( artorias_core_get_page_content_sidebar_classes() ); ?>">
	<div class="qodef-esports-match qodef-m <?php echo esc_attr( artorias_core_get_esports_match_holder_classes() ); ?>">
		<?php
		// Include esports match posts loop
		artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/parts/loop' );
		?>
	</div>

	<?php
	// Hook to include additional content after page content
	do_action( 'artorias_action_after_page_content' );
	?>

</div>
