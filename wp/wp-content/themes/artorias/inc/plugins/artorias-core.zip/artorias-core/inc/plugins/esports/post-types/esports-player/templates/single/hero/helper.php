<?php

if ( ! function_exists( 'artorias_core_include_esports_player_single_hero_template' ) ) {
	/**
	 * Function which includes additional module on single esports match page
	 */
	function artorias_core_include_esports_player_single_hero_template() {
		artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/single/hero/templates/hero' );
	}

	add_action( 'artorias_core_action_before_esports_player_content_holder', 'artorias_core_include_esports_player_single_hero_template' );
}
