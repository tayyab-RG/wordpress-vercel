<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-category-list/media-custom-fields.php';
include_once ARTORIAS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-category-list/class-artoriascore-product-category-list-shortcode.php';

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-category-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
