<?php
$hero_image_id  = artorias_core_get_post_value_through_levels( 'qodef_esports_team_single_hero_background_image' );
$hero_image_url = ! empty( wp_get_attachment_image_src( $hero_image_id, 'full' ) ) ? wp_get_attachment_image_src( $hero_image_id, 'full' )[0] : $hero_image_id;
?>
<?php if ( $hero_image_url ) : ?>
	<?php $style = 'background-image: url( ' . esc_url( $hero_image_url ) . ')'; ?>
	<div class="qodef-m-hero-image qodef--background" <?php qode_framework_inline_style( $style ); ?>></div>
<?php endif; ?>
