<?php
$tournaments = artorias_core_get_post_value_through_levels( 'qodef_esports_player_tournaments' );
?>
<?php if ( ! empty( $tournaments ) ) : ?>
	<div class="qodef-m-meta-item">
		<span class="qodef-m-meta-label">
			<?php echo esc_html__( 'Tournaments ', 'artorias-core' ); ?>
		</span>
		<div class="qodef-m-meta-content">
			<?php foreach ( $tournaments as $tournament ) : ?>
				<?php
				$tournament_name   = $tournament['qodef_esports_player_tournament_name'];
				$tournament_link   = $tournament['qodef_esports_player_tournament_link'];
				$tournament_target = ! empty( $tournament['qodef_esport_player_tournament_target'] ) ? $tournament['qodef_esport_player_tournament_target'] : '_blank';
				?>
				<?php if ( ! empty( $tournament_name ) ) : ?>
					<?php if ( ! empty( $tournament_link ) ): ?>
						<a class="qodef-m-tournament-link" href="<?php echo esc_url( $tournament_link ); ?>" target="<?php echo esc_attr( $tournament_target ); ?>">
					<?php else: ?>
						<span class="qodef-m-tournament-name">
					<?php endif; ?>
					<?php echo esc_html( $tournament_name ); ?>
					<?php if ( ! empty( $tournament_link ) ): ?>
						</a>
					<?php else: ?>
						</span>
					<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
	</div>
<?php endif; ?>
