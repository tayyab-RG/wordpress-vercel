<?php

if ( ! function_exists( 'artorias_core_add_esports_match_list_variation_compact' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function artorias_core_add_esports_match_list_variation_compact( $variations ) {
		$variations['compact'] = esc_html__( 'Compact', 'artorias-core' );

		return $variations;
	}

	add_filter( 'artorias_core_filter_esports_match_list_layouts', 'artorias_core_add_esports_match_list_variation_compact' );
	add_filter( 'artorias_core_filter_esports_match_simple_list_layouts', 'artorias_core_add_esports_match_list_variation_compact' );
}

if ( ! function_exists( 'artorias_core_add_esports_match_list_options_compact' ) ) {
	/**
	 * Function that add additional options for variation layout
	 *
	 * @param array $options
	 *
	 * @return array
	 */
	function artorias_core_add_esports_match_list_options_compact( $options ) {
		$info_below_options   = array();
		$margin_option        = array(
			'field_type' => 'text',
			'name'       => 'compact_result_margin_top',
			'title'      => esc_html__( 'Result Top Margin', 'artorias-core' ),
			'dependency' => array(
				'show' => array(
					'layout' => array(
						'values'        => 'compact',
						'default_value' => '',
					),
				),
			),
			'group'      => esc_html__( 'Layout', 'artorias-core' ),
		);
		$info_below_options[] = $margin_option;

		return array_merge( $options, $info_below_options );
	}

	add_filter( 'artorias_core_filter_esports_match_list_extra_options', 'artorias_core_add_esports_match_list_options_compact' );
}
