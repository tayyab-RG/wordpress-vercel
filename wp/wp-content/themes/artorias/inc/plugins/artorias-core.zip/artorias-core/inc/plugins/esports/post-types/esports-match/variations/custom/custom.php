<?php

if ( ! function_exists( 'artorias_core_add_esports_match_single_variation_custom' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function artorias_core_add_esports_match_single_variation_custom( $variations ) {
		$variations['custom'] = esc_html__( 'Custom', 'artorias-core' );

		return $variations;
	}

	add_filter( 'artorias_core_filter_esports_match_single_layout_options', 'artorias_core_add_esports_match_single_variation_custom' );
}
