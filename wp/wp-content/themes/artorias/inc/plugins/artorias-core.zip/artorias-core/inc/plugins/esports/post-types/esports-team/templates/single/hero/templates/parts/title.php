<?php
$title_tag_meta = artorias_core_get_post_value_through_levels( 'qodef_esports_team_single_title_tag' );
$title_tag      = ! empty( $title_tag_meta ) ? esc_attr( $title_tag_meta ) : 'h4';
?>
<?php echo '<' . esc_attr( $title_tag ); ?> itemprop="name" class="qodef-m-team-name entry-title"><?php the_title(); ?></<?php echo esc_attr( $title_tag ); ?>>
