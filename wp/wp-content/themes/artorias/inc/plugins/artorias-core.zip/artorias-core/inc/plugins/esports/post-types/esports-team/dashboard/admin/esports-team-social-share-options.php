<?php

if ( ! function_exists( 'artorias_core_add_esports_team_social_share_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function artorias_core_add_esports_team_social_share_options( $tab ) {

		if ( $tab ) {

			$tab->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_esports_team_enable_social_share',
					'title'         => esc_html__( 'Enable Social Share for Esports Team', 'artorias-core' ),
					'description'   => esc_html__( 'Enable this option to display social share sections on Esports Team singles and certain lists by default', 'artorias-core' ),
					'default_value' => 'yes',
				)
			);
		}
	}

	add_action( 'artorias_core_action_after_social_share_cpt_options_map', 'artorias_core_add_esports_team_social_share_options' );
}
