<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once ARTORIAS_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once ARTORIAS_CORE_PLUGINS_PATH . '/elementor/class-artoriascore-elementor-section-handler.php';
}
