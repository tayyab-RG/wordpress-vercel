<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-player/variations/standard-full-width/standard-full-width.php';
