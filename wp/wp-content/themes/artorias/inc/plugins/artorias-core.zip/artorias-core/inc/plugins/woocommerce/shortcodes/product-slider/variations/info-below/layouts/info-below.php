<li <?php wc_product_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php if ( has_post_thumbnail() ) { ?>
			<div class="qodef-woo-product-image">
				<?php artorias_core_template_part( 'plugins/woocommerce/shortcodes/product-slider', 'templates/post-info/mark' ); ?>
				<?php artorias_core_template_part( 'plugins/woocommerce/shortcodes/product-slider', 'templates/post-info/image', '', $params ); ?>
				<?php artorias_core_template_part( 'plugins/woocommerce/shortcodes/product-slider', 'templates/post-info/link' ); ?>
			</div>
		<?php } ?>
		<div class="qodef-woo-product-content">
			<?php artorias_core_template_part( 'plugins/woocommerce/shortcodes/product-slider', 'templates/post-info/title', '', $params ); ?>
			<div class="qodef-woo-product-content-inner">
                <div class="qodef-woo-product-actions">
				    <?php artorias_core_template_part( 'plugins/woocommerce/shortcodes/product-slider', 'templates/post-info/add-to-cart' ); ?>
                </div>
                <?php artorias_core_template_part( 'plugins/woocommerce/shortcodes/product-slider', 'templates/post-info/price', '', $params ); ?>
			</div>
		</div>
	</div>
</li>
