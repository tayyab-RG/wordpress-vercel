<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner" <?php qode_framework_inline_style( $this_shortcode->get_inner_styles( $params ) ); ?>>
		<div class="qodef-e-image">
			<?php
			// Include post list image template
			artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-team/shortcodes/esports-team-list', 'post-info/image', '', $params );
			?>
		</div>
		<div class="qodef-e-content">
			<?php
			// Include post title template
			artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-team/shortcodes/esports-team-list', 'post-info/title', '', $params );

			// Include post team social icons template
			artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-team/shortcodes/esports-team-list', 'post-info/team-social-icons', '', array_merge( $params, array( 'show_label' => true ) ) );
			?>
		</div>
	</div>
</article>
