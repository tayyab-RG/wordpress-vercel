<?php
$match_status    = get_post_meta( get_the_ID(), 'qodef_esports_match_single_status', true );
?>
<?php if ( ! empty( $match_status ) ): ?>
	<div class="qodef-m-match-status">
		<?php echo esc_html( artorias_core_get_esports_match_status( $match_status ) ); ?>
	</div>
	<div class="qodef-info-separator-end"></div>
<?php endif; ?>
