<?php
$date   = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_date' );
$hour   = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_hour' );
$minute = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_minute' );
?>
<?php if ( ! empty( $date ) ): ?>
	<?php $date = date_create( $date ); ?>
	<span class="qodef-m-date">
		<?php echo sprintf('%s,',esc_html( date_format( $date, get_option( 'date_format' ) ) )); ?>
	</span>
	<?php if ( ! empty( $hour ) && ! empty( $minute ) ): ?>
		<span class="qodef-m-time">
			<?php echo sprintf( '%s:%s', esc_html( $hour ), esc_html( $minute ) ); ?>
		</span>
	<?php endif; ?>
	<div class="qodef-info-separator-end"></div>
<?php endif; ?>
