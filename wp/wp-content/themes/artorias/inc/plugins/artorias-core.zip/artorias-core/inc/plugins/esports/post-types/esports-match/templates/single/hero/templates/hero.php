<div id="qodef-esports-match-single-hero">
	<?php
	// Include post match team 1 template
	artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/single/hero/templates/parts/match-team', '', array( 'team' => 'one' ) );

	// Include post match result template
	artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/single/hero/templates/parts/match-result' );

	// Include post match team 2 template
	artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/single/hero/templates/parts/match-team', '', array( 'team' => 'two' ) );

	// Include post hero background image template
	artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/single/hero/templates/parts/hero-background' );
	?>
</div>
