<?php

if ( ! function_exists( 'artorias_core_include_esports_match_single_hero_template' ) ) {
	/**
	 * Function which includes additional module on single esports match page
	 */
	function artorias_core_include_esports_match_single_hero_template() {
		if ( ! is_archive() ) {
			artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/single/hero/templates/hero' );
		}
	}

	add_action( 'artorias_core_action_before_esports_match_content_holder', 'artorias_core_include_esports_match_single_hero_template' );
}
