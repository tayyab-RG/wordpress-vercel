<a itemprop="url" class="qodef-m-opener" href="<?php echo esc_url( wc_get_cart_url() ); ?>">
	<?php echo sprintf( '%s (%s)', esc_html__( 'CART', 'artorias-core' ), WC()->cart->cart_contents_count ); ?>
</a>
