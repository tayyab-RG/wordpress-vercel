<?php
$is_enabled = artorias_core_get_post_value_through_levels( 'qodef_esports_team_enable_navigation' );
?>
<?php if ( 'yes' === $is_enabled ) : ?>
	<?php $through_same_game = 'yes' === artorias_core_get_post_value_through_levels( 'qodef_esports_team_navigation_through_same_game' ); ?>
	<div id="qodef-single-esports-team-navigation" class="qodef-m">
		<div class="qodef-m-inner">
			<?php
			$navigation_icon_class = 'qodef-m-nav-icon';
			$post_navigation       = array(
				'prev'      => array(
					'label' => '<span class="qodef-m-nav-label">' . esc_html__( 'Prev', 'artorias-core' ) . '</span>',
					'icon'  => artorias_core_get_svg_icon( 'pagination-arrow-left', $navigation_icon_class ),
				),
				'back-link' => array(),
				'next'      => array(
					'label' => '<span class="qodef-m-nav-label">' . esc_html__( 'Next', 'artorias-core' ) . '</span>',
					'icon'  => artorias_core_get_svg_icon( 'pagination-arrow-right', $navigation_icon_class ),
				),
			);
			if ( $through_same_game ) {
				if ( '' !== get_adjacent_post( true, '', true, 'esports-team-game' ) ) {
					$post_navigation['prev']['post'] = get_adjacent_post( true, '', true, 'esports-team-game' );
				}
				if ( '' !== get_adjacent_post( true, '', false, 'esports-team-game' ) ) {
					$post_navigation['next']['post'] = get_adjacent_post( true, '', false, 'esports-team-game' );
				}
			} else {
				if ( '' !== get_adjacent_post( false, '', true ) ) {
					$post_navigation['prev']['post'] = get_adjacent_post( false, '', true );
				}
				if ( '' !== get_adjacent_post( false, '', false ) ) {
					$post_navigation['next']['post'] = get_adjacent_post( false, '', false );
				}
			}
			?>
			<?php foreach ( $post_navigation as $key => $value ) : ?>
				<?php if ( isset( $post_navigation[$key]['post'] ) ) : ?>
					<?php
					$current_post = $value['post'];
					$post_id      = isset( $value['post_id'] ) && ! empty( $value['post_id'] ) ? $value['post_id'] : $current_post->ID;
					?>
					<a itemprop="url" class="qodef-m-nav qodef--<?php echo esc_attr( $key ); ?>" href="<?php echo esc_url( get_permalink( $post_id ) ); ?>">
						<?php if ( ! empty( $value['icon'] ) ) : ?>
							<?php echo qode_framework_wp_kses_html( 'html', $value['icon'] ); ?>
						<?php endif; ?>
						<?php if ( ! empty( $value['label'] ) ) : ?>
							<?php echo wp_kses( $value['label'], array( 'span' => array( 'class' => true ) ) ); ?>
						<?php endif; ?>
					</a>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
	</div>
<?php endif; ?>
