(function ( $ ) {
	'use strict';

	$( window ).on(
		'load',
		function () {
			qodefParallaxBackground.init();
		}
	);

	/**
	 * Init global parallax background functionality
	 */
	var qodefParallaxBackground = {
		init: function ( settings ) {
			this.$sections = $( '.qodef-parallax' );

			// Allow overriding the default config
			$.extend(
				this.$sections,
				settings
			);

			var isSupported = !qodefCore.html.hasClass( 'touchevents' ) && !qodefCore.body.hasClass( 'qodef-browser--edge' ) && !qodefCore.body.hasClass( 'qodef-browser--ms-explorer' );

			if ( this.$sections.length && isSupported ) {
				this.$sections.each(
					function () {
						if (!$( this ).hasClass('qodef-parallax--init')){//added from elementor js
							qodefParallaxBackground.ready($( this ));
						}
					}
				);
			}
		},
		ready: function ( $section ) {
			$section.rowHolder   = $section.find( '.qodef-parallax-row-holder' );
			$section.$imgHolder  = $section.find( '.qodef-parallax-img-holder' );
			$section.$imgWrapper = $section.find( '.qodef-parallax-img-wrapper' );
			$section.$img        = $section.find( 'img.qodef-parallax-img' );


			qodef.qodefWaitForImages.check(
				$section,
				function () {
					$section.$imgHolder.animate(
						{ opacity: 1 },
						1000
					);
					qodefParallaxBackground.calc( $section );
					qodefParallaxBackground.animateParallax( $section );
				}
			);

			//recalc
			$( window ).on(
				'resize',
				function () {
					qodefParallaxBackground.calc( $section );
				}
			);
		},
		calc: function ( $section ) {
			var speedRandom = $section.speedNormalized = gsap.utils.random(1.1, 1.14); //if 1 no effect will be applied, use values between -1 and 2
			$section.speed           = parseFloat( $section.rowHolder.attr( 'data-speed' ) );
			$section.speed           = $section.speed && ! isNaN( $section.speed ) ? $section.speed : speedRandom;
			$section.speedNormalized = ($section.speed - 1).toFixed(2);

			$section.$imgHolder.css( {
				'top': - Math.abs( $section.speedNormalized  * 100 ) + '%',
				'height': 100 +  Math.abs( $section.speedNormalized * 100 ) + '%'
			} );

			var wH = $section.$imgWrapper.height(),
				wW = $section.$imgWrapper.width(),
				heightDiff = $section.$img.height() - wH,
				widthDiff = $section.$img.width() - wW;

			if ( widthDiff < 0 && widthDiff <= heightDiff  ) {
				$section.$img.css(
					{
						'width': '100%',
						'height': 'auto',
					}
				);
			}

			if ( heightDiff < 0 && heightDiff <= widthDiff ) {
				$section.$img.css(
					{
						'height': '100%',
						'width': 'auto',
						'max-width': 'unset',
					}
				);
			}
		},
		animateParallax: function ( $section ) {
			if ( $section.speedNormalized == 0 ) return;

			var maxY = Math.round($section.outerHeight() * $section.speedNormalized - 10),//10 arbitrary num to avoid glitches
				duration = .5;

			gsap.registerPlugin(ScrollTrigger);

			const tl = gsap.timeline({defaults: {duration: 1},
				scrollTrigger: {
					trigger: $section,
					scrub: true,
					start: () => {
						return "top bottom"
					},
					end: () => {
						return "bottom top";
					},
					onUpdate: (self) => {
						gsap.to (
							$section.$imgWrapper,
							{
								y : maxY * self.progress.toFixed(2),
								duration: duration,
							},
						)
					}
				}
			});
		}
	};

	qodefCore.qodefParallaxBackground = qodefParallaxBackground;

})( jQuery );
