<?php
$match_status = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_status' );
?>
<?php if ( ! empty( $match_status ) ): ?>
	<div class="qodef-m-match-status">
		<?php echo esc_html( artorias_core_get_esports_match_status( $match_status ) ); ?>
	</div>
	<div class="qodef-info-separator-end"></div>
<?php endif; ?>
