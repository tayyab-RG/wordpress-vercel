<?php
$match_status    = get_post_meta( get_the_ID(), 'qodef_esports_match_single_status', true );
$result          = get_post_meta( get_the_ID(), 'qodef_esports_match_single_result', true );
$result_string   = 'in-progress' === $match_status || 'finished' === $match_status ? $result : artorias_core_get_template_part( 'plugins/esports/post-types/esports-match/assets/img', 'vs' );
$title_tag       = isset( $title_tag ) && ! empty( $title_tag ) ? $title_tag : 'h2';
$title_tag_class = 'qodef-' . $title_tag;
$result_styles   = isset( $result_styles ) ? $result_styles : '';
?>
<div class="qodef-e-result <?php echo esc_attr( $title_tag_class ); ?>" <?php qode_framework_inline_style( $result_styles ); ?>>
	<a itemprop="url" class="qodef-e-result-link" href="<?php echo the_permalink(); ?>">
		<?php echo qode_framework_wp_kses_html( 'html', $result_string ); ?>
	</a>
</div>
