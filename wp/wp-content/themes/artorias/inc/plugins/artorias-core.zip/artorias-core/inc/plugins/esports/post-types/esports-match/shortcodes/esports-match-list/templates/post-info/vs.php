<?php echo esc_html__( 'vs', 'artorias-core' ); ?>
