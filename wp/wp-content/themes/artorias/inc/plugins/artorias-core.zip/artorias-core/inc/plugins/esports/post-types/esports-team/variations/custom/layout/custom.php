<?php
// Hook to include additional content before esports team single item
do_action( 'artorias_core_action_before_esports_team_single_item' );
?>
	<article <?php post_class( 'qodef-esports-team-single-item qodef-e' ); ?>>
		<div class="qodef-e-inner">
			<div class="qodef-e-content">
				<div class="qodef-grid-inner">
					<div class="qodef-grid-item qodef-esports-team-info">
						<?php artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/parts/post-info/content' ); ?>
					</div>
				</div>
			</div>
		</div>
	</article>
<?php
// Hook to include additional content after esports team single item
do_action( 'artorias_core_action_after_esports_team_single_item' );
?>
