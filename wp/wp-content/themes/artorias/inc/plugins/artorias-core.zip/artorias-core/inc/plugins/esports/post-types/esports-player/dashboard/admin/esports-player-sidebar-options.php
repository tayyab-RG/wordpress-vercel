<?php

if ( ! function_exists( 'artorias_core_add_esports_player_single_sidebar_options' ) ) {
	/**
	 * Function that add sidebar options for esports player single module
	 */
	function artorias_core_add_esports_player_single_sidebar_options( $tab ) {

		if ( $tab ) {

			$tab->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_esports_player_single_sidebar_layout',
					'title'         => esc_html__( 'Sidebar Layout', 'artorias-core' ),
					'description'   => esc_html__( 'Choose default sidebar layout for esport singles', 'artorias-core' ),
					'default_value' => 'no-sidebar',
					'options'       => artorias_core_get_select_type_options_pool( 'sidebar_layouts', false ),
				)
			);

			$custom_sidebars = artorias_core_get_custom_sidebars();

			if ( ! empty( $custom_sidebars ) && count( $custom_sidebars ) > 1 ) {

				$tab->add_field_element(
					array(
						'field_type'  => 'select',
						'name'        => 'qodef_esports_player_single_custom_sidebar',
						'title'       => esc_html__( 'Custom Sidebar', 'artorias-core' ),
						'description' => esc_html__( 'Choose a custom sidebar to display on esports player singles', 'artorias-core' ),
						'options'     => $custom_sidebars,
					)
				);
			}

			$tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_esports_player_single_sidebar_grid_gutter',
					'title'       => esc_html__( 'Set Grid Gutter', 'artorias-core' ),
					'description' => esc_html__( 'Choose grid gutter size to set space between content and sidebar', 'artorias-core' ),
					'options'     => artorias_core_get_select_type_options_pool( 'items_space' ),
				)
			);
		}
	}

	add_action( 'artorias_core_action_after_esports_player_options_single', 'artorias_core_add_esports_player_single_sidebar_options' );
}
