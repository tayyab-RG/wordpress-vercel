<?php

if ( ! function_exists( 'artorias_core_generate_esports_match_single_layout' ) ) {
	/**
	 * Function that return default layout for custom post type single page
	 *
	 * @return string
	 */
	function artorias_core_generate_esports_match_single_layout() {
		$esports_match_template = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_layout' );
		$esports_match_template = ! empty( $esports_match_template ) ? $esports_match_template : '';

		return $esports_match_template;
	}

	add_filter( 'artorias_core_filter_esports_match_single_layout', 'artorias_core_generate_esports_match_single_layout' );
}

if ( ! function_exists( 'artorias_core_get_esports_match_holder_classes' ) ) {
	/**
	 * Function that return classes for the main esports match holder
	 *
	 * @return string
	 */
	function artorias_core_get_esports_match_holder_classes() {
		$classes = array( 'qodef-esports-match' );

		$item_layout = artorias_core_generate_esports_match_single_layout();
		if ( ! empty( $item_layout ) ) {
			$classes[] = 'qodef-layout--' . $item_layout;
		}

		return implode( ' ', $classes );
	}
}

if ( ! function_exists( 'artorias_core_set_esports_match_single_body_classes' ) ) {
	/**
	 * Function that add additional class name into global class list for body tag
	 *
	 * @param array $classes
	 *
	 * @return array
	 */
	function artorias_core_set_esports_match_single_body_classes( $classes ) {
		$item_layout = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_layout' );

		if ( is_singular( 'esports-match' ) && ! empty( $item_layout ) ) {
			$classes[] = 'qodef-layout--' . $item_layout;
		}

		return $classes;
	}

	add_filter( 'body_class', 'artorias_core_set_esports_match_single_body_classes' );
}

if ( ! function_exists( 'artorias_core_set_esports_match_single_page_inner_classes' ) ) {
	/**
	 * Function that set fake full width layout for esports match single layouts
	 *
	 * @return string|void
	 */
	function artorias_core_set_esports_match_single_page_inner_classes( $classes ) {
		$item_layout        = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_layout' );
		$full_width_layouts = apply_filters( 'artorias_core_filter_esports_match_single_full_width_layouts', array() );

		if ( is_singular( 'esports-match' ) && ! empty( $item_layout ) ) {
			foreach ( $full_width_layouts as $full_width_layout ) {
				if ( $item_layout === $full_width_layout ) {
					$classes = 'qodef-content-full-width';
				}
			}
		}

		return $classes;
	}

	add_filter( 'artorias_filter_page_inner_classes', 'artorias_core_set_esports_match_single_page_inner_classes' );
}

if ( ! function_exists( 'artorias_core_generate_esports_match_archive_with_shortcode' ) ) {
	/**
	 * Function that executes esports match list shortcode with params on archive pages
	 *
	 * @param string $tax      - type of taxonomy
	 * @param string $tax_slug - slug of taxonomy
	 */
	function artorias_core_generate_esports_match_archive_with_shortcode( $tax, $tax_slug ) {
		$params = array();

		$params['additional_params'] = 'tax';
		$params['layout']            = 'full-details';
		$params['tax']               = $tax;
		$params['tax_slug']          = $tax_slug;
		$params['columns']           = 1;
		$params['posts_per_page']    = 12;
		$params['pagination_type']   = 'standard'; // FIXME get default from filter

		echo ArtoriasCore_Esports_Match_List_Shortcode::call_shortcode( $params );
	}
}

if ( ! function_exists( 'artorias_core_is_esports_match_title_enabled' ) ) {
	/**
	 * Function that check is module enabled
	 *
	 * @param bool $is_enabled
	 *
	 * @return bool
	 */
	function artorias_core_is_esports_match_title_enabled( $is_enabled ) {
		if ( is_singular( 'esports-match' ) ) {
			$esports_match_title = artorias_core_get_post_value_through_levels( 'qodef_enable_esports_match_title' );
			$is_enabled          = '' === $esports_match_title ? $is_enabled : ( 'no' === $esports_match_title ? false : true );
		}

		return $is_enabled;
	}

	add_filter( 'artorias_core_filter_is_page_title_enabled', 'artorias_core_is_esports_match_title_enabled' );
}

if ( ! function_exists( 'artorias_core_esports_match_title_grid' ) ) {
	/**
	 * Function that check is option enabled
	 *
	 * @param bool $enable_title_grid
	 *
	 * @return bool
	 */
	function artorias_core_esports_match_title_grid( $enable_title_grid ) {
		if ( is_singular( 'esports-match' ) ) {
			$esports_match_title_grid = artorias_core_get_post_value_through_levels( 'qodef_set_esports_match_title_area_in_grid' );
			$enable_title_grid        = '' === $esports_match_title_grid ? $enable_title_grid : ( 'no' === $esports_match_title_grid ? false : true );
		}

		return $enable_title_grid;
	}

	add_filter( 'artorias_core_filter_page_title_in_grid', 'artorias_core_esports_match_title_grid' );
}

if ( ! function_exists( 'artorias_core_esports_match_breadcrumbs_title' ) ) {
	/**
	 * Improve main breadcrumbs template with additional cases
	 *
	 * @param string|html $wrap_child
	 * @param array       $settings
	 *
	 * @return string|html
	 */
	function artorias_core_esports_match_breadcrumbs_title( $wrap_child, $settings ) {
		if ( is_tax( 'esports-match-game' ) ) {
			$wrap_child  = '';
			$term_object = get_term( get_queried_object_id(), 'esports-match-game' );

			if ( isset( $term_object->parent ) && 0 !== $term_object->parent ) {
				$parent     = get_term( $term_object->parent );
				$wrap_child .= sprintf( $settings['link'], get_term_link( $parent->term_id ), $parent->name ) . $settings['separator'];
			}

			$wrap_child .= sprintf( $settings['current_item'], single_cat_title( '', false ) );
		} elseif ( is_singular( 'esports-match' ) ) {
			$wrap_child = '';
			$post_terms = wp_get_post_terms( get_the_ID(), 'esports-match-game' );

			if ( ! empty( $post_terms ) ) {
				$post_term = $post_terms[0];
				if ( isset( $post_term->parent ) && 0 !== $post_term->parent ) {
					$parent     = get_term( $post_term->parent );
					$wrap_child .= sprintf( $settings['link'], get_term_link( $parent->term_id ), $parent->name ) . $settings['separator'];
				}
				$wrap_child .= sprintf( $settings['link'], get_term_link( $post_term ), $post_term->name ) . $settings['separator'];
			}

			$wrap_child .= sprintf( $settings['current_item'], get_the_title() );
		}

		return $wrap_child;
	}

	add_filter( 'artorias_core_filter_breadcrumbs_content', 'artorias_core_esports_match_breadcrumbs_title', 10, 2 );
}

if ( ! function_exists( 'artorias_core_set_esports_match_custom_sidebar_name' ) ) {
	/**
	 * Function that return sidebar name
	 *
	 * @param string $sidebar_name
	 *
	 * @return string
	 */
	function artorias_core_set_esports_match_custom_sidebar_name( $sidebar_name ) {
		if ( is_singular( 'esports-match' ) ) {
			$option = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_custom_sidebar' );
		} elseif ( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'esports-match' );

			foreach ( $taxonomies as $tax ) {
				if ( is_tax( $tax ) ) {
					$option = artorias_core_get_post_value_through_levels( 'qodef_page_custom_sidebar' );
				}
			}
		}

		if ( isset( $option ) && ! empty( $option ) ) {
			$sidebar_name = $option;
		}

		return $sidebar_name;
	}

	add_filter( 'artorias_filter_sidebar_name', 'artorias_core_set_esports_match_custom_sidebar_name' );
}

if ( ! function_exists( 'artorias_core_set_esports_match_sidebar_layout' ) ) {
	/**
	 * Function that return sidebar layout
	 *
	 * @param string $layout
	 *
	 * @return string
	 */
	function artorias_core_set_esports_match_sidebar_layout( $layout ) {
		if ( is_singular( 'esports-match' ) ) {
			$option = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_sidebar_layout' );
		} elseif ( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'esports-match' );
			foreach ( $taxonomies as $tax ) {
				if ( is_tax( $tax ) ) {
					$option = artorias_core_get_post_value_through_levels( 'qodef_page_sidebar_layout' );
				}
			}
		}

		if ( isset( $option ) && ! empty( $option ) ) {
			$layout = $option;
		}

		return $layout;
	}

	add_filter( 'artorias_filter_sidebar_layout', 'artorias_core_set_esports_match_sidebar_layout' );
}

if ( ! function_exists( 'artorias_core_set_esports_match_sidebar_grid_gutter_classes' ) ) {
	/**
	 * Function that returns grid gutter classes
	 *
	 * @param string $classes
	 *
	 * @return string
	 */
	function artorias_core_set_esports_match_sidebar_grid_gutter_classes( $classes ) {
		if ( is_singular( 'esports-match' ) ) {
			$option   = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_sidebar_grid_gutter' );
			$template = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_sidebar_grid_gutter' );
		} elseif ( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'esports-match' );
			foreach ( $taxonomies as $tax ) {
				if ( is_tax( $tax ) ) {
					$option = artorias_core_get_post_value_through_levels( 'qodef_page_sidebar_grid_gutter' );
				}
			}
		}
		if ( isset( $option ) && ! empty( $option ) ) {
			$classes = 'qodef-gutter--' . esc_attr( $option );
		}

		return $classes;
	}

	add_filter( 'artorias_filter_grid_gutter_classes', 'artorias_core_set_esports_match_sidebar_grid_gutter_classes' );
}

if ( ! function_exists( 'artorias_core_get_esports_match_single_post_taxonomies' ) ) {
	/**
	 * Function that return single post taxonomies list
	 *
	 * @param int $post_id
	 *
	 * @return array
	 */
	function artorias_core_get_esports_match_single_post_taxonomies( $post_id ) {
		$options = array();

		if ( ! empty( $post_id ) ) {
			$options['esports-match-game'] = wp_get_post_terms( $post_id, 'esports-match-game' );
		}

		return $options;
	}
}

if ( ! function_exists( 'artorias_core_get_esports_match_status' ) ) {
	/**
	 * Function that return match status form match single
	 *
	 * @param      $option
	 * @param bool $enable_default
	 *
	 * @return array|mixed|string
	 */
	function artorias_core_get_esports_match_status( $option = '', $enable_default = false ) {
		$match_status['upcoming']    = esc_html__( 'Upcoming', 'artorias-core' );
		$match_status['in-progress'] = esc_html__( 'In Progress', 'artorias-core' );
		$match_status['finished']    = esc_html__( 'Finished', 'artorias-core' );
		$match_status['delayed']     = esc_html__( 'Delayed', 'artorias-core' );

		if ( $enable_default ) {
			$match_status[''] = esc_html__( 'Default', 'qode-framework' );
		}

		if ( ! empty( $option ) ) {
			return $match_status[$option];
		} else {
			return $match_status;
		}
	}
}

if ( ! function_exists( 'artorias_core_include_esports_match_shortcodes_widget' ) ) {
	/**
	 * Function that includes widgets
	 */
	function artorias_core_include_esports_match_shortcodes_widget() {
		foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-match/shortcodes/*/widget/include.php' ) as $widget ) {
			include_once $widget;
		}
	}

	add_action( 'qode_framework_action_before_widgets_register', 'artorias_core_include_esports_match_shortcodes_widget' );
}
