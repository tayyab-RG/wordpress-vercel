<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/helper.php';
include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/dashboard/admin/esports-options.php';

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/*/include.php' ) as $module ) {
	include_once $module;
}
