<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-team/shortcodes/esports-team-list/class-artoriascore-esports-team-list-shortcode.php';

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-team/shortcodes/esports-team-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
