<?php

if ( ! function_exists( 'artorias_core_add_esports_player_single_variation_standard_full_width' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function artorias_core_add_esports_player_single_variation_standard_full_width( $variations ) {
		$variations['standard-full-width'] = esc_html__( 'Standard Full Width', 'artorias-core' );

		return $variations;
	}

	add_filter( 'artorias_core_filter_esports_player_single_layout_options', 'artorias_core_add_esports_player_single_variation_standard_full_width' );
}

if ( ! function_exists( 'artorias_core_set_default_esports_player_single_variation_standard' ) ) {
	/**
	 * Function that set default variation layout for current module
	 *
	 * @return string
	 */
	function artorias_core_set_default_esports_player_single_variation_standard() {
		return 'standard-full-width';
	}

	add_filter( 'artorias_core_filter_esports_player_single_layout_default_value', 'artorias_core_set_default_esports_player_single_variation_standard' );
}

if ( ! function_exists( 'artorias_core_set_esports_player_single_variation_standard_full_width_layout' ) ) {
	/**
	 * Function that add variation in full width template list
	 *
	 * @param $layouts
	 *
	 * @return array
	 */
	function artorias_core_set_esports_player_single_variation_standard_full_width_layout( $layouts ) {
		$layouts[] = 'standard-full-width';

		return $layouts;
	}

	add_filter( 'artorias_core_filter_esports_player_single_full_width_layouts', 'artorias_core_set_esports_player_single_variation_standard_full_width_layout' );
}
