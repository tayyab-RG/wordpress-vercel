<?php if ( has_post_thumbnail() ) : ?>
	<div class="qodef-m-player-image">
		<?php the_post_thumbnail(); ?>
	</div>
<?php endif; ?>
