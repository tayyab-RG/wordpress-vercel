<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-team/variations/standard-full-width/standard-full-width.php';
