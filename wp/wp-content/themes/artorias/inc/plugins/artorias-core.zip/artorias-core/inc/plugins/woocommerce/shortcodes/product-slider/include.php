<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-slider/class-artoriascore-product-slider-shortcode.php';

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-slider/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
