<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<div class="qodef-e-image">
			<?php
			// Include post list image template
			artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-player/shortcodes/esports-player-list', 'post-info/image', 'background', $params );
			?>
		</div>
		<?php
		// Include post title template
		artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-player/shortcodes/esports-player-list', 'post-info/title', '', $params );

		// Include post player team role template
		artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-player/shortcodes/esports-player-list', 'post-info/player-team-role', '', $params );

		// Include post player social icons template
		artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-player/shortcodes/esports-player-list', 'post-info/player-social-icons', '', $params );
		?>
	</div>
</article>
