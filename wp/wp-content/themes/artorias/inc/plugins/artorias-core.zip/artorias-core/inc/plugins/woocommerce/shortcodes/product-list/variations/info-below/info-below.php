<?php

if ( ! function_exists( 'artorias_core_add_product_list_variation_info_below' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function artorias_core_add_product_list_variation_info_below( $variations ) {
		$variations['info-below'] = esc_html__( 'Info Below', 'artorias-core' );

		return $variations;
	}

	add_filter( 'artorias_core_filter_product_list_layouts', 'artorias_core_add_product_list_variation_info_below' );
}

if ( ! function_exists( 'artorias_core_register_shop_list_info_below_actions' ) ) {
	/**
	 * Function that override product item layout for current variation type
	 */
	function artorias_core_register_shop_list_info_below_actions() {

		// IMPORTANT - THIS CODE NEED TO COPY/PASTE ALSO INTO THEME FOLDER MAIN WOOCOMMERCE FILE - set_default_layout method

		// Add additional tags around product list item
		add_action( 'woocommerce_before_shop_loop_item', 'artorias_add_product_list_item_holder', 5 ); // permission 5 is set because woocommerce_template_loop_product_link_open hook is added on 10
		add_action( 'woocommerce_after_shop_loop_item', 'artorias_add_product_list_item_holder_end', 30 ); // permission 30 is set because woocommerce_template_loop_add_to_cart hook is added on 10

		// Add additional tags around product list item image
		add_action( 'woocommerce_before_shop_loop_item_title', 'artorias_add_product_list_item_image_holder', 5 ); // permission 5 is set because woocommerce_show_product_loop_sale_flash hook is added on 10
		add_action( 'woocommerce_before_shop_loop_item_title', 'artorias_add_product_list_item_image_holder_end', 30 ); // permission 30 is set because woocommerce_template_loop_product_thumbnail hook is added on 10

		// Add additional tags around product list item content
		add_action( 'woocommerce_shop_loop_item_title', 'artorias_add_product_list_item_content_holder', 5 ); // permission 5 is set because woocommerce_template_loop_product_title hook is added on 10
		add_action( 'woocommerce_after_shop_loop_item', 'artorias_add_product_list_item_content_holder_end', 20 ); // permission 20 is set because woocommerce_template_loop_add_to_cart hook is added on 10

		// Add additional content wrapper around add to cart and price
		add_action( 'woocommerce_after_shop_loop_item', 'artorias_add_product_list_item_additional_content_holder', 6 );
		add_action( 'woocommerce_after_shop_loop_item', 'artorias_add_product_list_item_additional_content_holder_end', 19 );

		// Change price position on product list
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 ); // permission 10 is default
		add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_price', 18 ); // permission 18 is set because artorias_add_product_list_item_additional_content_holder end hook is added on 19

		// Change add to cart position on product list
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 ); // permission 10 is default
        add_action( 'woocommerce_after_shop_loop_item', 'artorias_add_product_list_item_actions_holder', 15 );
        add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 16 ); // permission 17 is set because artorias_add_product_list_item_additional_content_holder end hook is added on 19
        add_action( 'woocommerce_after_shop_loop_item', 'artorias_add_product_list_item_actions_holder_end', 17 );
	}

	add_action( 'artorias_core_action_shop_list_item_layout_info-below', 'artorias_core_register_shop_list_info_below_actions' );
}
