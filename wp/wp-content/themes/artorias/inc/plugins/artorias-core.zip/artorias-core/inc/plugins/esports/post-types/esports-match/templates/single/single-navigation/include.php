<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-match/templates/single/single-navigation/helper.php';
include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-match/templates/single/single-navigation/dashboard/admin/single-navigation-options.php';
