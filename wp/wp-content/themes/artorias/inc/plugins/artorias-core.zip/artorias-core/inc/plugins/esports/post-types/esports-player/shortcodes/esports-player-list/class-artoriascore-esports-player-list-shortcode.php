<?php

if ( ! function_exists( 'artorias_core_add_esports_player_list_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function artorias_core_add_esports_player_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'ArtoriasCore_Esports_Player_List_Shortcode';

		return $shortcodes;
	}

	add_filter( 'artorias_core_filter_register_shortcodes', 'artorias_core_add_esports_player_list_shortcode' );
}

if ( class_exists( 'ArtoriasCore_List_Shortcode' ) ) {
	class ArtoriasCore_Esports_Player_List_Shortcode extends ArtoriasCore_List_Shortcode {

		public function __construct() {
			$this->set_post_type( 'esports-player' );
			$this->set_layouts( apply_filters( 'artorias_core_filter_esports_player_list_layouts', array() ) );

			add_filter( 'artorias_core_filter_map_additional_query_params', array( $this, 'add_additional_query_params' ), 10, 2 );
			add_action( 'artorias_core_action_map_query_options_after_additional', array( $this, 'add_additional_query_fields' ) );
			add_filter( 'artorias_core_filter_additional_query_args', array( $this, 'additional_query' ), 10, 3 );

			parent::__construct();
		}

		public function add_additional_query_params( $params, $base ) {
			if ( 'artorias_core_esports_player_list' === $base ) {
				$params['team'] = esc_html__( 'Team', 'artorias-core' );
			}

			return $params;
		}

		public function add_additional_query_fields( $group ) {
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'team',
					'title'      => esc_html__( 'Team', 'artorias-core' ),
					'options'    => qode_framework_get_cpt_items(
						'esports-team',
						array(
							'numberposts' => '-1',
						)
					),
					'group'      => $group,
					'dependency' => array(
						'show' => array(
							'additional_params' => array(
								'values'        => 'team',
								'default_value' => '',
							),
						),
					),
				)
			);
		}

		public function additional_query( $args, $atts, $post_type ) {
			if ( $post_type === $this->get_post_type() ) {
				if ( ! empty( $atts['additional_params'] ) && 'team' === $atts['additional_params'] && ! empty( $atts['team'] ) ) {
					$team_players     = get_post_meta( $atts['team'], 'qodef_esports_team_players', true );
					$team_players_ids = array();
					if ( ! empty( $team_players ) ) {
						foreach ( $team_players as $team_player ) {
							$team_players_ids[] = $team_player['qodef_esports_team_player'];
						}
					}

					$args['orderby']  = 'post__in';
					$args['post__in'] = $team_players_ids;
				}
			}

			return $args;
		}

		public function map_shortcode() {
			$this->set_shortcode_path( ARTORIAS_CORE_PLUGINS_URL_PATH . '/esports/post-types/esports-player/shortcodes/esports-player-list' );
			$this->set_base( 'artorias_core_esports_player_list' );
			$this->set_name( esc_html__( 'Esports Player List', 'artorias-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays list of esports players', 'artorias-core' ) );
			$this->set_scripts( apply_filters( 'artorias_core_filter_esports_player_list_register_assets', array() ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'artorias-core' ),
				)
			);
			$this->map_list_options();
			$this->map_query_options( array( 'post_type' => $this->get_post_type() ) );
			$this->map_layout_options(
				array(
					'layouts' => $this->get_layouts(),
				)
			);
			$this->map_additional_options( array( 'exclude_filter' => true ) );
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'artorias_core_esports_player_list', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function load_assets() {
			parent::load_assets();

			do_action( 'artorias_core_action_esports_player_list_load_assets', $this->get_atts() );
		}

		public function render( $options, $content = null ) {
			parent::render( $options );

			$atts = $this->get_atts();

			$atts['post_type']       = $this->get_post_type();
			$atts['taxonomy_filter'] = $this->get_post_type_filter_taxonomy( $atts );

			// Additional query args
			$atts['additional_query_args'] = $this->get_additional_query_args( $atts );

			$atts['query_result']   = new \WP_Query( artorias_core_get_query_params( $atts ) );
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['slider_attr']    = $this->get_slider_data( $atts );
			$atts['data_attr']      = artorias_core_get_pagination_data( ARTORIAS_CORE_REL_PATH, 'plugins/esports/post-types/esports-player/shortcodes', 'esports-player-list', 'esports-player', $atts );

			$atts['this_shortcode'] = $this;

			return artorias_core_get_template_part( 'plugins/esports/post-types/esports-player/shortcodes/esports-player-list', 'templates/content', $atts['behavior'], $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-esports-player-list';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-item-layout--' . $atts['layout'] : '';

			$list_classes            = $this->get_list_classes( $atts );
			$hover_animation_classes = $this->get_hover_animation_classes( $atts );
			$holder_classes          = array_merge( $holder_classes, $list_classes, $hover_animation_classes );

			return implode( ' ', $holder_classes );
		}

		public function get_item_classes( $atts ) {
			$item_classes = $this->init_item_classes();

			$list_item_classes = $this->get_list_item_classes( $atts );

			$item_classes = array_merge( $item_classes, $list_item_classes );

			return implode( ' ', $item_classes );
		}

		public function get_title_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['text_transform'];
			}

			return $styles;
		}
	}
}
