<?php
$tagline = artorias_core_get_post_value_through_levels( 'qodef_esports_player_single_tagline' );
?>
<?php if ( ! empty( $tagline ) ): ?>
	<h2 class="qodef-m-tagline">
		<?php echo esc_html( $tagline ); ?>
	</h2>
<?php endif; ?>
