<?php

if ( ! function_exists( 'artorias_core_add_esports_match_single_variation_standard_full_width' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function artorias_core_add_esports_match_single_variation_standard_full_width( $variations ) {
		$variations['standard-full-width'] = esc_html__( 'Standard Full Width', 'artorias-core' );

		return $variations;
	}

	add_filter( 'artorias_core_filter_esports_match_single_layout_options', 'artorias_core_add_esports_match_single_variation_standard_full_width' );
}

if ( ! function_exists( 'artorias_core_set_default_esports_match_single_variation_standard_full_width' ) ) {
	/**
	 * Function that set default variation layout for current module
	 *
	 * @return string
	 */
	function artorias_core_set_default_esports_match_single_variation_standard_full_width() {
		return 'standard-full-width';
	}

	add_filter( 'artorias_core_filter_esports_match_single_layout_default_value', 'artorias_core_set_default_esports_match_single_variation_standard_full_width' );
}

if ( ! function_exists( 'artorias_core_set_esports_match_single_variation_standard_full_width_layout' ) ) {
	/**
	 * Function that add variation in full width template list
	 *
	 * @param $layouts
	 *
	 * @return array
	 */
	function artorias_core_set_esports_match_single_variation_standard_full_width_layout( $layouts ) {
		$layouts[] = 'standard-full-width';

		return $layouts;
	}

	add_filter( 'artorias_core_filter_esports_match_single_full_width_layouts', 'artorias_core_set_esports_match_single_variation_standard_full_width_layout' );
}

if ( ! function_exists( 'artorias_core_set_esports_match_single_variation_standard_full_width_additional_open_tag' ) ) {
	/**
	 * Function that print additional open tag in full width template
	 *
	 * @return void
	 */
	function artorias_core_set_esports_match_single_variation_standard_full_width_additional_open_tag() {
		if ( is_singular( 'esports-match' ) ) {
			$layout = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_layout' );

			if ( 'standard-full-width' === $layout ) {
				echo '<div class="qodef-content-grid qodef--width-exception">';
			}
		}
	}

	add_action( 'artorias_core_action_before_esports_match_content_holder', 'artorias_core_set_esports_match_single_variation_standard_full_width_additional_open_tag', 11 ); // priority 11 because hero is on 10
}

if ( ! function_exists( 'artorias_core_set_esports_match_single_variation_standard_full_width_additional_close_tag' ) ) {
	/**
	 * Function that print additional close tag in full width template
	 *
	 * @return void
	 */
	function artorias_core_set_esports_match_single_variation_standard_full_width_additional_close_tag() {
		if ( is_singular( 'esports-match' ) ) {
			$layout = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_layout' );

			if ( 'standard-full-width' === $layout ) {
				echo '</div>';
			}
		}
	}

	add_action( 'artorias_core_action_after_esports_match_content_holder', 'artorias_core_set_esports_match_single_variation_standard_full_width_additional_close_tag' );
}
