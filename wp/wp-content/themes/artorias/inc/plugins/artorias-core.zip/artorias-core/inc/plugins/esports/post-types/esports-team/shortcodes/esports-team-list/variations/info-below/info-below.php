<?php

if ( ! function_exists( 'artorias_core_add_esports_team_list_variation_info_below' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function artorias_core_add_esports_team_list_variation_info_below( $variations ) {
		$variations['info-below'] = esc_html__( 'Info Below', 'artorias-core' );

		return $variations;
	}

	add_filter( 'artorias_core_filter_esports_team_list_layouts', 'artorias_core_add_esports_team_list_variation_info_below' );
}
