<?php

if ( ! function_exists( 'artorias_core_esports_post_types' ) ) {
	/**
	 * Register plugins custom post types
	 *
	 * @param $class
	 *
	 * @return void
	 */
	function artorias_core_esports_post_types( $class ) {
		foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/*', GLOB_ONLYDIR ) as $post_type ) {

			if ( 'dashboard' !== basename( $post_type ) ) {
				$is_disabled = artorias_core_performance_get_option_value( $post_type, 'artorias_core_performance_post_type_' );

				if ( empty( $is_disabled ) ) {
					$class->set_allowed_post_types( $post_type );
				}
			}
		}
	}

	add_action( 'artorias_core_action_add_custom_post_type', 'artorias_core_esports_post_types' );
}
