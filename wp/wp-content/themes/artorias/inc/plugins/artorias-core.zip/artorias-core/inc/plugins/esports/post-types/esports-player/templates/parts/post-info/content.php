<div class="qodef-m-player-content">
	<?php the_content(); ?>
</div>
