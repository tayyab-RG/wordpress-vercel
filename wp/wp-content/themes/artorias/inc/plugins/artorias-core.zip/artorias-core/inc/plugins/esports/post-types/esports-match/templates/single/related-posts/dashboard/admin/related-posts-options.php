<?php

if ( ! function_exists( 'artorias_core_add_esports_match_single_related_posts_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function artorias_core_add_esports_match_single_related_posts_options( $page ) {

		if ( $page ) {

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_esports_match_single_enable_related_posts',
					'title'         => esc_html__( 'Related Posts', 'artorias-core' ),
					'description'   => esc_html__( 'Enabling this option will show related posts section below post content on esports match single', 'artorias-core' ),
					'default_value' => 'no',
				)
			);
		}
	}

	add_action( 'artorias_core_action_after_esports_match_options_single', 'artorias_core_add_esports_match_single_related_posts_options' );
}
