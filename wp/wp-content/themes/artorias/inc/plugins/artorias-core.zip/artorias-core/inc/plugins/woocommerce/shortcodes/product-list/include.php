<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/class-artoriascore-product-list-shortcode.php';

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
