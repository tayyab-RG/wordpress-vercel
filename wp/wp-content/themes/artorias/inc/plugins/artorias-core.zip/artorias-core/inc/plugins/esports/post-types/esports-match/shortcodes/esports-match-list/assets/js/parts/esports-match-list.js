(function ( $ ) {
	'use strict';

	var shortcode = 'artorias_core_esports_match_list';

	qodefCore.shortcodes[shortcode] = {};

	if ( typeof qodefCore.listShortcodesScripts === 'object' ) {
		$.each(
			qodefCore.listShortcodesScripts,
			function ( key, value ) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}

	$( window ).load(
		function () {
			qodefMatchListAppear.init();
		}
	);

	$(document).on(
		'artorias_trigger_get_new_posts',
		function () {
			qodefMatchListAppear.init();
		}
	);

	var qodefMatchListAppear = {
		init: function () {
			this.holder = $('.qodef-esports-match-list.qodef-item-layout--full-details.qodef--has-appear');


			if (this.holder.length) {
				this.holder.each(
					function () {
						var holder = $(this);

						qodefMatchListAppear.initAppear(holder);
					}
				);
			}
		},
		initAppear: function ( holder ) {
			var articles = holder.find('.qodef-e'),
				startAppearIndex = 0;

			function setDelays(){
				articles.each(
					function (index, element){
						var rect = element.getBoundingClientRect();
						var isInViewport = rect.top >= 0 &&
							rect.left >= 0 &&
							rect.bottom <= $(window).height() + rect.height  &&
							rect.right <= $(window).width();



						if (isInViewport) {
							startAppearIndex++;

							$(element).css('--qodef-transition-delay', `${startAppearIndex * .2}s`);
						}
					}
				)
			};

			qodefCore.qodefIsInViewport.check(
				holder,
				()=> setDelays()
			);
		}
	};

	qodefCore.shortcodes[shortcode].qodefAppear = qodefCore.qodefAppear;

	qodefCore.shortcodes[shortcode].qodefMatchListAppear = qodefCore.qodefMatchListAppear;

})( jQuery );
