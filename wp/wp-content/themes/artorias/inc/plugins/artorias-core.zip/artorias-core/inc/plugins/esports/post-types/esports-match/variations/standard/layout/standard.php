<?php
// Hook to include additional content before esports match single item
do_action( 'artorias_core_action_before_esports_match_single_item' );
?>
<article <?php post_class( 'qodef-esports-match-single qodef-variations--standard qodef-m' ); ?>>
	<div class="qodef-m-inner">
		<div class="qodef-m-content">
			<div class="qodef-m-content-inner">
				<?php
				// Include post title template
				artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/parts/post-info/title' );
				?>
				<div class="qodef-m-match-info qodef-e-info">
					<?php
					// Include post games template
					artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/parts/post-info/games' );

					// Include post match status template
					artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/parts/post-info/match-status' );

					// Include post match date/time template
					artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/parts/post-info/match-date-time' );
					?>
				</div>
				<?php
				// Include post content template
				artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/parts/post-info/content' );
				?>
			</div>
			<?php
			// Include post social share template
			artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/parts/post-info/social-share' );
			?>
		</div>
	</div>
</article>
<?php
// Hook to include additional content after esports match single item
do_action( 'artorias_core_action_after_esports_match_single_item' );
?>
