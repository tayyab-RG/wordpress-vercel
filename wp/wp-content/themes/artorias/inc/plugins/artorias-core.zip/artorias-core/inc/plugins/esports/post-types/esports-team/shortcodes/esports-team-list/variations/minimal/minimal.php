<?php

if ( ! function_exists( 'artorias_core_add_esports_team_list_variation_minimal' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function artorias_core_add_esports_team_list_variation_minimal( $variations ) {
		$variations['minimal'] = esc_html__( 'Minimal', 'artorias-core' );

		return $variations;
	}

	add_filter( 'artorias_core_filter_esports_team_list_layouts', 'artorias_core_add_esports_team_list_variation_minimal' );
}

if ( ! function_exists( 'artorias_core_add_esports_team_list_options_minimal' ) ) {
	/**
	 * Function that add additional options for variation layout
	 *
	 * @param array $options
	 *
	 * @return array
	 */
	function artorias_core_add_esports_team_list_options_minimal( $options ) {
		$minimal_options   = array();
		$gap_option        = array(
			'field_type' => 'text',
			'name'       => 'minimal_gap',
			'title'      => esc_html__( 'Gap', 'artorias-core' ),
			'dependency' => array(
				'show' => array(
					'layout' => array(
						'values'        => 'minimal',
						'default_value' => '',
					),
				),
			),
			'group'      => esc_html__( 'Layout', 'artorias-core' ),
		);
		$minimal_options[] = $gap_option;

		return array_merge( $options, $minimal_options );
	}

	add_filter( 'artorias_core_filter_esports_team_list_extra_options', 'artorias_core_add_esports_team_list_options_minimal' );
}
