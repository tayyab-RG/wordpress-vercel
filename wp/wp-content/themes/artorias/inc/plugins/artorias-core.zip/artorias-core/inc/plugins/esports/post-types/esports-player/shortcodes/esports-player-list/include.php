<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-player/shortcodes/esports-player-list/class-artoriascore-esports-player-list-shortcode.php';

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-player/shortcodes/esports-player-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
