<?php
$title_tag         = isset( $title_tag ) && ! empty( $title_tag ) ? $title_tag : 'h2';
$team_id           = get_post_meta( get_the_ID(), 'qodef_esports_match_single_team_' . $team, true );
$team_name         = get_the_title( $team_id );
$include_title_tag = isset( $include_title_tag ) && false === $include_title_tag ? false : true;
?>
<?php if ( ! empty( $team_name ) ): ?>
	<?php if ( $include_title_tag ): ?>
		<?php echo '<' . esc_attr( $title_tag ); ?> itemprop="name" class="qodef-e-team-name entry-title" <?php qode_framework_inline_style( $this_shortcode->get_title_styles( $params ) ); ?>>
		<a itemprop="url" class="qodef-e-team-name-link" href="<?php echo the_permalink($team_id); ?>">
	<?php else: ?>
		<span class="qodef-e-team-name">
	<?php endif; ?>
	<?php echo esc_html( $team_name ); ?>
	<?php if ( $include_title_tag ): ?>
		</a>
		<?php echo '</' . esc_attr( $title_tag ); ?>>
	<?php else: ?>
		</span>
	<?php endif; ?>
<?php endif; ?>
