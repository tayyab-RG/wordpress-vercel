<?php

if ( ! function_exists( 'artorias_core_add_esports_team_single_hero_meta_box' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function artorias_core_add_esports_team_single_hero_meta_box( $page, $general_tab ) {

		if ( $page ) {

			$general_tab->add_field_element(
				array(
					'field_type'    => 'image',
					'name'          => 'qodef_esports_team_single_hero_background_image',
					'title'         => esc_html__( 'Hero Background Image', 'artorias-core' ),
					'description'   => esc_html__( 'Choose background image for hero section', 'artorias-core' ),
					'default_value' => defined( 'ARTORIAS_ASSETS_ROOT' ) ? ARTORIAS_CORE_PLUGINS_URL_PATH . '/esports/assets/img/hero.png' : '',
					'multiple'      => 'no',
				)
			);
		}
	}

	add_action( 'artorias_core_action_before_esports_team_meta_box_map', 'artorias_core_add_esports_team_single_hero_meta_box', 10, 2 );
}
