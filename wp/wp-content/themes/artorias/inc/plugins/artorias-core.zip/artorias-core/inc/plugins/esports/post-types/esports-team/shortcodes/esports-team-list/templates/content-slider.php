<div <?php qode_framework_class_attribute( $holder_classes ); ?> <?php qode_framework_inline_attr( $slider_attr, 'data-options' ); ?>>
	<div class="swiper-wrapper">
		<?php
		// Include loop template
		artorias_core_template_part( 'plugins/esports/post-types/esports-team/shortcodes/esports-team-list', 'templates/loop', '', $params );
		?>
	</div>
	<?php
	// Include slider navigation template
	artorias_core_template_part( 'content', 'templates/swiper-nav', '', $params );

	// Include slider pagination template
	artorias_core_template_part( 'content', 'templates/swiper-pag', '', $params );
	?>
</div>
