<?php
$team_id = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_team_' . $team );
?>
<?php if ( class_exists( 'ArtoriasCore_Esports_Team_List_Shortcode' ) && ! empty( $team_id ) ) : ?>
	<?php
	$params = array(
		'custom_class'        => 'qodef--no-bottom-space qodef-m-team-' . $team,
		'columns'             => '1',
		'images_proportion'   => 'custom',
		'custom_image_width'  => artorias_core_esports_get_team_logo_image_size(),
		'custom_image_height' => artorias_core_esports_get_team_logo_image_size(),
		'posts_per_page'      => 1,
		'additional_params'   => 'id',
		'post_ids'            => $team_id,
		'layout'              => 'minimal',
		'title_tag'           => 'h2',
	);

	echo ArtoriasCore_Esports_Team_List_Shortcode::call_shortcode( $params );
	?>
<?php endif; ?>
