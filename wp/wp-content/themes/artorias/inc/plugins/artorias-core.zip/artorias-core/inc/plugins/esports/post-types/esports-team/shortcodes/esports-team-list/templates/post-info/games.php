<?php
$games = wp_get_post_terms( get_the_ID(), 'esports-team-game' );
?>
<?php if ( ! empty( $games ) ) : ?>
	<div class="qodef-e-games">
		<?php echo get_the_term_list( get_the_ID(), 'esports-team-game', '', '<span class="qodef-info-separator-single"></span>' ); ?>
	</div>
<?php endif; ?>
