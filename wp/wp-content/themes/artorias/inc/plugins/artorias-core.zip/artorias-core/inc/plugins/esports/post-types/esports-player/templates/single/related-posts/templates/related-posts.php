<?php
$is_enabled       = artorias_core_get_post_value_through_levels( 'qodef_esports_player_single_enable_related_posts' );
$player_id        = get_the_ID();
$team_id          = artorias_core_get_esports_player_team( $player_id, 'id' );
$team_players     = get_post_meta( $team_id, 'qodef_esports_team_players', true );
$team_players_ids = '';
?>
<?php if ( 'yes' === $is_enabled && ! empty( $team_players ) && class_exists( 'ArtoriasCore_Esports_Player_List_Shortcode' ) ) : ?>
	<?php foreach ( $team_players as $team_player ): ?>
		<?php if ( intval( $team_player['qodef_esports_team_player'] ) !== $player_id ) : ?>
			<?php $team_players_ids .= $team_player['qodef_esports_team_player'] . ','; ?>
		<?php endif; ?>
	<?php endforeach; ?>
	<div id="qodef-esports-player-single-related-items">
		<?php
		$params = array(
			'custom_class'      => 'qodef--no-bottom-space',
			'behavior'          => 'slider',
			'columns'           => '3',
			'space'             => 'large',
			'posts_per_page'    => - 1,
			'additional_params' => 'id',
			'post_ids'          => $team_players_ids,
			'layout'            => 'info-below',
			'title_tag'         => 'h5',
		);

		echo ArtoriasCore_Esports_Player_List_Shortcode::call_shortcode( $params );
		?>
	</div>
<?php endif; ?>
