<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-player/templates/single/related-posts/helper.php';
include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-player/templates/single/related-posts/dashboard/admin/related-posts-options.php';
