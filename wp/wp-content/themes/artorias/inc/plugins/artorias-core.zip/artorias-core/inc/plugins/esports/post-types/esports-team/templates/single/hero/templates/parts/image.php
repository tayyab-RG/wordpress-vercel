<?php if ( has_post_thumbnail() ) : ?>
	<div class="qodef-m-team-logo">
		<?php the_post_thumbnail( array( artorias_core_esports_get_team_logo_image_size( $team_single = true ), artorias_core_esports_get_team_logo_image_size( $team_single = true ) ) ); ?>
	</div>
<?php endif; ?>
