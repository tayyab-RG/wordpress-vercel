<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-match/shortcodes/esports-match-list/variations/details/details.php';
