<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/order-tracking/class-artoriascore-order-tracking-shortcode.php';
