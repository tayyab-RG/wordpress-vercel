<?php
// Hook to include additional content before esports player single item
do_action( 'artorias_core_action_before_esports_player_single_item' );
?>
<article <?php post_class( 'qodef-esports-player-single qodef-variations--standard-full-width qodef-m' ); ?>>
	<div class="qodef-m-inner">
		<div class="qodef-m-content">
			<div class="qodef-content-grid qodef--width-exception">
				<div class="qodef-m-content-inner">
					<?php
					// Include post player label template
					artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/post-info/player-label' );

					// Include post player tagline template
					artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/post-info/player-tagline' );

					// Include post content template
					artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/post-info/content' );
					?>
					<div class="qodef-m-meta">
						<?php
						// Include post player nationality template
						artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/post-info/player-nationality' );

						// Include post player age template
						artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/post-info/player-age' );

						// Include post player team role template
						artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/post-info/player-team-role' );

						// Include post player tournaments template
						artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/post-info/player-tournaments' );

						// Include post social share template
						artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/post-info/social-share' );
						?>
					</div>
				</div>
				<div class="qodef-m-custom-field">
					<?php
					// Include post player custom fields template
					artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/post-info/player-custom-fields' );
					?>
				</div>
			</div>
			<?php
			// Include post player social tabs template
			artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/post-info/player-social-tabs' );
			?>
		</div>
	</div>
</article>
<?php
// Hook to include additional content after esports player single item
do_action( 'artorias_core_action_after_esports_player_single_item' );
?>
