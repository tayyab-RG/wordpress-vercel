<div class="qodef-m-team-content">
	<?php the_content(); ?>
</div>
