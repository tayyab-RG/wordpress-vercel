<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-match/templates/single/hero/helper.php';
include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-match/templates/single/hero/dashboard/meta-box/hero-meta-box.php';
