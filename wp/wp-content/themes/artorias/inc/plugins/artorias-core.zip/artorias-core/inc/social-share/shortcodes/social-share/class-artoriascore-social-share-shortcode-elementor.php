<?php

class ArtoriasCore_Social_Share_Shortcode_Elementor extends ArtoriasCore_Elementor_Widget_Base {

	public function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'artorias_core_social_share' );

		parent::__construct( $data, $args );
	}
}

artorias_core_register_new_elementor_widget( new ArtoriasCore_Social_Share_Shortcode_Elementor() );
