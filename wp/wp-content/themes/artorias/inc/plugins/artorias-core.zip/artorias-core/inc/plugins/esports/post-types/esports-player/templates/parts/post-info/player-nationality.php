<?php
$nationality = artorias_core_get_post_value_through_levels( 'qodef_esports_player_single_nationality' );
?>
<?php if ( ! empty( $nationality ) ): ?>
	<div class="qodef-m-meta-item">
		<span class="qodef-m-meta-label">
			<?php echo esc_html__( 'Nationality', 'artorias-core' ); ?>
		</span>
		<span class="qodef-m-meta-content">
			<?php echo esc_html( $nationality ); ?>
		</span>
	</div>
<?php endif; ?>
