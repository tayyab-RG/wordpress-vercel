<?php

if ( ! function_exists( 'artorias_core_add_social_share_variation_dropdown' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function artorias_core_add_social_share_variation_dropdown( $variations ) {
		$variations['dropdown'] = esc_html__( 'Dropdown', 'artorias-core' );

		return $variations;
	}

	add_filter( 'artorias_core_filter_social_share_layouts', 'artorias_core_add_social_share_variation_dropdown' );
	add_filter( 'artorias_core_filter_social_share_layout_options', 'artorias_core_add_social_share_variation_dropdown' );
}
