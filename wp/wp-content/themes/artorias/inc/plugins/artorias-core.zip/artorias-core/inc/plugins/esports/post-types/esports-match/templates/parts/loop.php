<?php

if ( have_posts() ) {
	while ( have_posts() ) :
		the_post();

		// Hook to include additional content before post item
		do_action( 'artorias_core_action_before_esports_match_item' );

		$item_layout = apply_filters( 'artorias_core_filter_esports_match_single_layout', '' );

		// Include post item
		artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'variations/' . $item_layout . '/layout/' . $item_layout );

		// Hook to include additional content after post item
		do_action( 'artorias_core_action_after_esports_match_item' );

	endwhile; // End of the loop.
} else {
	// Include global posts not found
	artorias_core_theme_template_part( 'content', 'templates/parts/posts-not-found' );
}

wp_reset_postdata();
