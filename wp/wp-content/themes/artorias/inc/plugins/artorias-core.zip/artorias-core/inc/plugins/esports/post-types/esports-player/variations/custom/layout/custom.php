<?php
// Hook to include additional content before esports player single item
do_action( 'artorias_core_action_before_esports_player_single_item' );
?>
	<article <?php post_class( 'qodef-esports-player-single-item qodef-e' ); ?>>
		<div class="qodef-e-inner">
			<div class="qodef-e-content">
				<div class="qodef-grid-inner">
					<div class="qodef-grid-item qodef-esports-player-info">
						<?php artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/post-info/content' ); ?>
					</div>
				</div>
			</div>
		</div>
	</article>
<?php
// Hook to include additional content after esports player single item
do_action( 'artorias_core_action_after_esports_player_single_item' );
?>
