<?php

if ( ! function_exists( 'artorias_core_add_esports_match_list_variation_full_details' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function artorias_core_add_esports_match_list_variation_full_details( $variations ) {
		$variations['full-details'] = esc_html__( 'Full Details', 'artorias-core' );

		return $variations;
	}

	add_filter( 'artorias_core_filter_esports_match_list_layouts', 'artorias_core_add_esports_match_list_variation_full_details' );
}
