<?php

include_once ARTORIAS_CORE_INC_PATH . '/title/helper.php';
include_once ARTORIAS_CORE_INC_PATH . '/title/class-artoriascore-title.php';
include_once ARTORIAS_CORE_INC_PATH . '/title/class-artoriascore-titles.php';
