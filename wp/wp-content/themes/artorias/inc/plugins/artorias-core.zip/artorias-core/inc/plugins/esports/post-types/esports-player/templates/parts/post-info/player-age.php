<?php
$date_of_birth = artorias_core_get_post_value_through_levels( 'qodef_esports_player_single_date_of_birth' );
?>
<?php if ( ! empty( $date_of_birth ) ): ?>
	<?php
	$age = date_diff( date_create( date( 'Y-m-d' ) ), date_create( $date_of_birth ) );
	?>
	<div class="qodef-m-meta-item">
		<span class="qodef-m-meta-label">
			<?php echo esc_html__( 'Player Age', 'artorias-core' ); ?>
		</span>
		<span class="qodef-m-meta-content">
			<?php echo sprintf( esc_html__( '%s yr', 'artorias-core' ), $age->y ); ?>
		</span>
	</div>
<?php endif; ?>
