<?php
$team_role = artorias_core_get_post_value_through_levels( 'qodef_esports_player_single_team_role' );
?>
<?php if ( ! empty( $team_role ) ): ?>
	<div class="qodef-m-meta-item">
		<span class="qodef-m-meta-label">
			<?php echo esc_html__( 'Player Role', 'artorias-core' ); ?>
		</span>
		<span class="qodef-m-meta-content">
			<?php echo esc_html( $team_role ); ?>
		</span>
	</div>
<?php endif; ?>
