<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-team/helper.php';

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-team/dashboard/admin/*.php' ) as $module ) {
	include_once $module;
}

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-team/dashboard/meta-box/*.php' ) as $module ) {
	include_once $module;
}

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-team/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-team/templates/single/*/include.php' ) as $single_part ) {
	include_once $single_part;
}
