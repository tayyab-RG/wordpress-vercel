<?php
$date   = get_post_meta( get_the_ID(), 'qodef_esports_match_single_date', true );
$hour   = get_post_meta( get_the_ID(), 'qodef_esports_match_single_hour', true );
$minute = get_post_meta( get_the_ID(), 'qodef_esports_match_single_minute', true );
?>
<?php if ( ! empty( $date ) ): ?>
	<?php $date = date_create( $date ); ?>
	<span class="qodef-m-date-wrapper">
		<span class="qodef-m-date">
			<?php echo sprintf( '%s', esc_html( date_format( $date, get_option( 'date_format' ) ) ) ); ?>
		</span>
		<span class="qodef-info-separator-inner">,</span>
	</span>
	<?php if ( ! empty( $hour ) && ! empty( $minute ) ): ?>
		<div class="qodef-info-separator-single"></div>
		<span class="qodef-m-time">
			<?php echo sprintf( '%s:%s', esc_html( $hour ), esc_html( $minute ) ); ?>
		</span>
	<?php endif; ?>
	<div class="qodef-info-separator-end"></div>
<?php endif; ?>
