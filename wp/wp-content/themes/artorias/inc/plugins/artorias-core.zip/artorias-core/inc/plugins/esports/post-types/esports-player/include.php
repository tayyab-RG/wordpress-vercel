<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-player/helper.php';

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-player/dashboard/admin/*.php' ) as $module ) {
	include_once $module;
}

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-player/dashboard/meta-box/*.php' ) as $module ) {
	include_once $module;
}

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-player/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}

foreach ( glob( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-player/templates/single/*/include.php' ) as $single_part ) {
	include_once $single_part;
}
