<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<div class="qodef-e-image">
			<?php
			// Include post background image template
			artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/image', 'background', $params );
			?>
		</div>
		<div class="qodef-e-content">
			<?php
			// Include post title from team names template
			artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/team/title', 'team-names', $params );
			?>
			<div class="qodef-e-match-info qodef-e-info">
				<?php
				// Include post match date/time template
				artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/match-date-time' );

				// Include post games template
				artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/games' );
				?>
			</div>
		</div>
		<?php
		// Include post link template
		artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/link' );
		?>
	</div>
</article>
