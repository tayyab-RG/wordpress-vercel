<div class="qodef-grid-item <?php echo esc_attr( artorias_core_get_page_content_sidebar_classes() ); ?>">
	<div class="qodef-esports-player qodef-m <?php echo esc_attr( artorias_core_get_esports_player_holder_classes() ); ?>">
		<?php
		// Include esports player posts loop
		artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/parts/loop' );
		?>
	</div>
</div>
