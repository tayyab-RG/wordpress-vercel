<?php

if ( ! function_exists( 'artorias_core_add_esports_player_title_options' ) ) {
	/**
	 * Function that add title options for esports player module
	 */
	function artorias_core_add_esports_player_title_options( $tab ) {

		if ( $tab ) {

			$tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_enable_esports_player_title',
					'title'       => esc_html__( 'Enable Title on Esports Player Single', 'artorias-core' ),
					'description' => esc_html__( 'Use this option to enable/disable esports player single title', 'artorias-core' ),
					'options'     => artorias_core_get_select_type_options_pool( 'yes_no' ),
				)
			);

			$tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_set_esports_player_title_area_in_grid',
					'title'       => esc_html__( 'Esports Player Title in Grid', 'artorias-core' ),
					'description' => esc_html__( 'Enabling this option will set esports player title area to be in grid', 'artorias-core' ),
					'options'     => artorias_core_get_select_type_options_pool( 'yes_no' ),
				)
			);
		}
	}

	add_action( 'artorias_core_action_after_esports_player_options_single', 'artorias_core_add_esports_player_title_options' );
}
