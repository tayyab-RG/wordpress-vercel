(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.artorias_core_product_category_list                    = {};
	qodefCore.shortcodes.artorias_core_product_category_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.artorias_core_product_category_list.qodefSwiper        = qodef.qodefSwiper;

})( jQuery );
