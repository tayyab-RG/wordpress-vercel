<p class="qodef-m-order-details">
	<span class="qodef-m-order-label"><?php esc_html_e( 'Total:', 'artorias-core' ); ?></span><?php wc_cart_totals_subtotal_html(); ?>
</p>
