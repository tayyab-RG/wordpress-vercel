<?php
$team_players = artorias_core_get_post_value_through_levels( 'qodef_esports_team_players' );
?>
<?php if ( class_exists( 'ArtoriasCore_Esports_Player_List_Shortcode' ) && ! empty( $team_players ) ) : ?>
	<?php
	$params = array(
		'custom_class'      => 'qodef--no-bottom-space qodef-m-player-list',
		'columns'           => '3',
		'space'             => 'large',
		'posts_per_page'    => - 1,
		'additional_params' => 'team',
		'team'              => get_the_ID(),
		'layout'            => 'info-below',
		'title_tag'         => 'h5',
	);

	echo ArtoriasCore_Esports_Player_List_Shortcode::call_shortcode( $params );
	?>
<?php endif; ?>
