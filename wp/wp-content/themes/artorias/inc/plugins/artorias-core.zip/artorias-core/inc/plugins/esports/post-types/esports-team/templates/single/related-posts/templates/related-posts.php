<?php
$post_id       = get_the_ID();
$is_enabled    = artorias_core_get_post_value_through_levels( 'qodef_esports_team_single_enable_related_posts' );
$related_posts = artorias_core_get_custom_post_type_related_posts( $post_id, artorias_core_get_esports_team_single_post_taxonomies( $post_id ) );
?>
<?php if ( 'yes' === $is_enabled && ! empty( $related_posts ) && class_exists( 'ArtoriasCore_Esports_Team_List_Shortcode' ) ) : ?>
	<div id="qodef-esports-team-single-related-items">
		<?php
		$params = apply_filters(
			'artorias_core_filter_esports_team_single_related_posts_params',
			array(
				'custom_class'      => 'qodef--no-bottom-space',
				'columns'           => '3',
				'posts_per_page'    => 3,
				'additional_params' => 'id',
				'post_ids'          => $related_posts['items'],
				'layout'            => 'compact',
				'title_tag'         => 'h5',
			)
		);

		echo ArtoriasCore_Esports_Team_List_Shortcode::call_shortcode( $params );
		?>
	</div>
<?php endif; ?>
