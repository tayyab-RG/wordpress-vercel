<?php

include_once ARTORIAS_CORE_INC_PATH . '/side-area/widgets/side-area-opener/class-artoriascore-side-area-opener-widget.php';
