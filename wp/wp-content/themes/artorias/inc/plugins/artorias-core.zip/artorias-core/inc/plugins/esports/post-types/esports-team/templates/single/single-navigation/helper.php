<?php

if ( ! function_exists( 'artorias_core_include_esports_team_single_post_navigation_template' ) ) {
	/**
	 * Function which includes additional module on single esports team page
	 */
	function artorias_core_include_esports_team_single_post_navigation_template() {
		artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/single/single-navigation/templates/single-navigation' );
	}

	add_action( 'artorias_core_action_after_esports_team_single_item', 'artorias_core_include_esports_team_single_post_navigation_template' );
}
