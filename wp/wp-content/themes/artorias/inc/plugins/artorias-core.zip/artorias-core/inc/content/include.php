<?php

include_once ARTORIAS_CORE_INC_PATH . '/content/helper.php';
