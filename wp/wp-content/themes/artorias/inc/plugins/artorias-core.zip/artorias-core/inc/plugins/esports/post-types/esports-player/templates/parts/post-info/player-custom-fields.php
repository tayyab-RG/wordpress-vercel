<?php
$custom_fields = artorias_core_get_post_value_through_levels( 'qodef_esports_player_custom_fields' );
?>
<?php if ( ! empty( $custom_fields ) ) : ?>
	<?php foreach ( $custom_fields as $custom_field ) : ?>
		<?php
		$custom_field_label  = $custom_field['qodef_esports_player_custom_field_label'];
		$custom_field_name   = $custom_field['qodef_esports_player_custom_field_name'];
		$custom_field_link   = $custom_field['qodef_esports_player_custom_field_link'];
		$custom_field_target = ! empty( $custom_field['qodef_esport_player_custom_field_target'] ) ? $custom_field['qodef_esport_player_custom_field_target'] : '_blank';
		?>
		<div class="qodef-m-custom-field-item">
			<span class="qodef-m-custom-field-label">
				<?php if ( ! empty( $custom_field_label ) ) : ?>
					<?php echo esc_html( $custom_field_label ); ?>
				<?php endif; ?>
			</span>
			<div class="qodef-m-custom-field-content">
				<?php if ( ! empty( $custom_field_name ) ) : ?>
					<?php if ( ! empty( $custom_field_link ) ): ?>
						<a class="qodef-m-custom-field-link" href="<?php echo esc_url( $custom_field_link ); ?>" target="<?php echo esc_attr( $custom_field_target ); ?>">
					<?php else: ?>
						<span class="qodef-m-custom-field-name">
					<?php endif; ?>
					<?php echo esc_html( $custom_field_name ); ?>
					<?php if ( ! empty( $custom_field_link ) ): ?>
						</a>
					<?php else: ?>
						</span>
					<?php endif; ?>
				<?php endif; ?>
			</div>
		</div>
	<?php endforeach; ?>
<?php endif; ?>
