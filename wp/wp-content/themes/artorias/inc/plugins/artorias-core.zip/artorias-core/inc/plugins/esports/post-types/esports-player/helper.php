<?php

if ( ! function_exists( 'artorias_core_generate_esports_player_single_layout' ) ) {
	/**
	 * Function that return default layout for custom post type single page
	 *
	 * @return string
	 */
	function artorias_core_generate_esports_player_single_layout() {
		$esports_player_template = artorias_core_get_post_value_through_levels( 'qodef_esports_player_single_layout' );
		$esports_player_template = ! empty( $esports_player_template ) ? $esports_player_template : '';

		return $esports_player_template;
	}

	add_filter( 'artorias_core_filter_esports_player_single_layout', 'artorias_core_generate_esports_player_single_layout' );
}

if ( ! function_exists( 'artorias_core_get_esports_player_holder_classes' ) ) {
	/**
	 * Function that return classes for the main esports player holder
	 *
	 * @return string
	 */
	function artorias_core_get_esports_player_holder_classes() {
		$classes = array( 'qodef-esports-player' );

		$item_layout = artorias_core_generate_esports_player_single_layout();
		if ( ! empty( $item_layout ) ) {
			$classes[] = 'qodef-layout--' . $item_layout;
		}

		return implode( ' ', $classes );
	}
}

if ( ! function_exists( 'artorias_core_set_esports_player_single_body_classes' ) ) {
	/**
	 * Function that add additional class name into global class list for body tag
	 *
	 * @param array $classes
	 *
	 * @return array
	 */
	function artorias_core_set_esports_player_single_body_classes( $classes ) {
		$item_layout = artorias_core_get_post_value_through_levels( 'qodef_esports_player_single_layout' );

		if ( is_singular( 'esports-player' ) && ! empty( $item_layout ) ) {
			$classes[] = 'qodef-layout--' . $item_layout;
		}

		return $classes;
	}

	add_filter( 'body_class', 'artorias_core_set_esports_player_single_body_classes' );
}

if ( ! function_exists( 'artorias_core_set_esports_player_single_page_inner_classes' ) ) {
	/**
	 * Function that set fake full width layout for esports player single layouts
	 *
	 * @return string|void
	 */
	function artorias_core_set_esports_player_single_page_inner_classes( $classes ) {
		$item_layout        = artorias_core_get_post_value_through_levels( 'qodef_esports_player_single_layout' );
		$full_width_layouts = apply_filters( 'artorias_core_filter_esports_player_single_full_width_layouts', array() );

		if ( is_singular( 'esports-player' ) && ! empty( $item_layout ) ) {
			foreach ( $full_width_layouts as $full_width_layout ) {
				if ( $item_layout === $full_width_layout ) {
					$classes = 'qodef-content-full-width';
				}
			}
		}

		return $classes;
	}

	add_filter( 'artorias_filter_page_inner_classes', 'artorias_core_set_esports_player_single_page_inner_classes' );
}

if ( ! function_exists( 'artorias_core_is_esports_player_title_enabled' ) ) {
	/**
	 * Function that check is module enabled
	 *
	 * @param bool $is_enabled
	 *
	 * @return bool
	 */
	function artorias_core_is_esports_player_title_enabled( $is_enabled ) {

		if ( is_singular( 'esports-player' ) ) {
			$esports_player_title = artorias_core_get_post_value_through_levels( 'qodef_enable_esports_player_title' );
			$is_enabled           = '' === $esports_player_title ? $is_enabled : ( 'no' === $esports_player_title ? false : true );
		}

		return $is_enabled;
	}

	add_filter( 'artorias_core_filter_is_page_title_enabled', 'artorias_core_is_esports_player_title_enabled' );
}

if ( ! function_exists( 'artorias_core_esports_player_title_grid' ) ) {
	/**
	 * Function that check is option enabled
	 *
	 * @param bool $enable_title_grid
	 *
	 * @return bool
	 */
	function artorias_core_esports_player_title_grid( $enable_title_grid ) {
		if ( is_singular( 'esports-player' ) ) {
			$esports_player_title_grid = artorias_core_get_post_value_through_levels( 'qodef_set_esports_player_title_area_in_grid' );
			$enable_title_grid         = '' === $esports_player_title_grid ? $enable_title_grid : ( 'no' === $esports_player_title_grid ? false : true );
		}

		return $enable_title_grid;
	}

	add_filter( 'artorias_core_filter_page_title_in_grid', 'artorias_core_esports_player_title_grid' );
}

if ( ! function_exists( 'artorias_core_esports_player_breadcrumbs_title' ) ) {
	/**
	 * Improve main breadcrumbs template with additional cases
	 *
	 * @param string|html $wrap_child
	 * @param array       $settings
	 *
	 * @return string|html
	 */
	function artorias_core_esports_player_breadcrumbs_title( $wrap_child, $settings ) {
		if ( is_singular( 'esports-player' ) ) {
			$wrap_child = '';
			$team       = artorias_core_get_esports_player_team( get_the_ID() );

			if ( ! empty( $team ) ) {
				$wrap_child .= sprintf( '<a href="%s">%s</a>', esc_attr( $team['link'] ), esc_html( $team['name'] ) ) . $settings['separator'];
			}

			$wrap_child .= sprintf( $settings['current_item'], get_the_title() );
		}

		return $wrap_child;
	}

	add_filter( 'artorias_core_filter_breadcrumbs_content', 'artorias_core_esports_player_breadcrumbs_title', 10, 2 );
}

if ( ! function_exists( 'artorias_core_set_esports_player_custom_sidebar_name' ) ) {
	/**
	 * Function that return sidebar name
	 *
	 * @param string $sidebar_name
	 *
	 * @return string
	 */
	function artorias_core_set_esports_player_custom_sidebar_name( $sidebar_name ) {

		if ( is_singular( 'esports-player' ) ) {
			$option = artorias_core_get_post_value_through_levels( 'qodef_esports_player_single_custom_sidebar' );
		}

		if ( isset( $option ) && ! empty( $option ) ) {
			$sidebar_name = $option;
		}

		return $sidebar_name;
	}

	add_filter( 'artorias_filter_sidebar_name', 'artorias_core_set_esports_player_custom_sidebar_name' );
}

if ( ! function_exists( 'artorias_core_set_esports_player_sidebar_layout' ) ) {
	/**
	 * Function that return sidebar layout
	 *
	 * @param string $layout
	 *
	 * @return string
	 */
	function artorias_core_set_esports_player_sidebar_layout( $layout ) {

		if ( is_singular( 'esports-player' ) ) {
			$option = artorias_core_get_post_value_through_levels( 'qodef_esports_player_single_sidebar_layout' );
		}

		if ( isset( $option ) && ! empty( $option ) ) {
			$layout = $option;
		}

		return $layout;
	}

	add_filter( 'artorias_filter_sidebar_layout', 'artorias_core_set_esports_player_sidebar_layout' );
}

if ( ! function_exists( 'artorias_core_set_esports_player_sidebar_grid_gutter_classes' ) ) {
	/**
	 * Function that returns grid gutter classes
	 *
	 * @param string $classes
	 *
	 * @return string
	 */
	function artorias_core_set_esports_player_sidebar_grid_gutter_classes( $classes ) {

		if ( is_singular( 'esports-player' ) ) {
			$option = artorias_core_get_post_value_through_levels( 'qodef_esports_player_single_sidebar_grid_gutter' );
		} elseif ( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'esports-player' );
			foreach ( $taxonomies as $tax ) {
				if ( is_tax( $tax ) ) {
					$option = artorias_core_get_post_value_through_levels( 'qodef_page_sidebar_grid_gutter' );
				}
			}
		}
		if ( isset( $option ) && ! empty( $option ) ) {
			$classes = 'qodef-gutter--' . esc_attr( $option );
		}

		return $classes;
	}

	add_filter( 'artorias_filter_grid_gutter_classes', 'artorias_core_set_esports_player_sidebar_grid_gutter_classes' );
}

if ( ! function_exists( 'artorias_core_get_esports_player_team' ) ) {
	/**
	 * Function that return team link/title or id for a given player id
	 *
	 * @param $player_id
	 * @param $option
	 *
	 * @return array|int|string
	 */
	function artorias_core_get_esports_player_team( $player_id, $option = 'full' ) {
		$team       = '';
		$team_found = false;
		$teams      = qode_framework_get_cpt_items(
			'esports-team',
			array(
				'numberposts' => '-1',
			)
		);

		foreach ( $teams as $team_id => $team_name ) {
			$team_players = get_post_meta( $team_id, 'qodef_esports_team_players', true );

			if ( ! empty( $team_players ) ) {
				foreach ( $team_players as $team_player ) {
					if ( intval( $team_player['qodef_esports_team_player'] ) === $player_id ) {
						$team_found = true;
						break;
					}
				}
			}

			if ( true === $team_found ) {
				break;
			}
		}

		if ( true === $team_found ) {
			if ( 'id' === $option ) {
				$team = $team_id;
			} else {
				$team = array(
					'link' => get_permalink( $team_id ),
					'name' => get_the_title( $team_id ),
				);
			}
		}

		return $team;
	}
}
