<p class="qodef-m-posts-not-found"><?php esc_html_e( 'No products in the cart.', 'artorias-core' ); ?></p>
