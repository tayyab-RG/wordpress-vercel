<?php

include_once ARTORIAS_CORE_INC_PATH . '/social-share/shortcodes/social-share/widget/class-artoriascore-social-share-widget.php';
