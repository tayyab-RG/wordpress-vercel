<?php
$social_links  = artorias_core_get_post_value_through_levels( 'qodef_esports_player_social_icons' );
$tabs_children = array();
?>
<?php if ( class_exists( 'ArtoriasCore_Tabs_Shortcode' ) && ! empty( $social_links ) ): ?>
	<?php foreach ( $social_links as $social_link ) : ?>
		<?php
		$tabs_children[] = array(
			'item_layout'      => 'standard',
			'item_title'       => $social_link['qodef_esports_player_icon_label'],
			'item_text'        => '',
			'item_image'       => $social_link['qodef_esports_player_icon_image'],
			'item_link_url'    => $social_link['qodef_esports_player_icon_link'],
			'item_link_target' => $social_link['qodef_esports_player_icon_target'],
		);
		?>
	<?php endforeach; ?>
	<?php
	$tabs_params = array(
		'custom_class' => 'qodef-m-social-tabs',
		'children'     => urlencode( json_encode( $tabs_children ) ),
	);

	echo ArtoriasCore_Tabs_Shortcode::call_shortcode( $tabs_params );
	?>
<?php endif; ?>
