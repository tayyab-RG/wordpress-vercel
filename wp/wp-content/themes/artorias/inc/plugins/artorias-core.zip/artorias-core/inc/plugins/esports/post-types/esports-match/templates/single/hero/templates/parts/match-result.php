<?php
$match_status  = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_status' );
$result        = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_result' );
$result_string = 'in-progress' === $match_status || 'finished' === $match_status ? $result : artorias_core_get_template_part( 'plugins/esports/post-types/esports-match/assets/img', 'vs' );
?>
<div class="qodef-m-result qodef-h1">
	<?php echo qode_framework_wp_kses_html( 'html', $result_string ); ?>
</div>
