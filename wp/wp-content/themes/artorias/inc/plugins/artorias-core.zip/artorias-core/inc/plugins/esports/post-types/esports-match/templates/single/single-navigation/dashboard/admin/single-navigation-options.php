<?php

if ( ! function_exists( 'artorias_core_add_esports_match_single_navigation_options' ) ) {
	/**
	 * Function that add additional custom post type single global options
	 *
	 * @param object $page
	 */
	function artorias_core_add_esports_match_single_navigation_options( $page ) {

		if ( $page ) {

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_esports_match_enable_navigation',
					'title'         => esc_html__( 'Navigation', 'artorias-core' ),
					'description'   => esc_html__( 'Enabling this option will turn on esports match navigation functionality', 'artorias-core' ),
					'default_value' => 'yes',
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_esports_match_navigation_through_same_game',
					'title'         => esc_html__( 'Navigation Through Same Game', 'artorias-core' ),
					'description'   => esc_html__( 'Enabling this option will make esports match navigation sort through current game', 'artorias-core' ),
					'default_value' => 'no',
					'dependency'    => array(
						'show' => array(
							'qodef_esports_match_enable_navigation' => array(
								'values'        => 'yes',
								'default_value' => 'yes',
							),
						),
					),
				)
			);
		}
	}

	add_action( 'artorias_core_action_after_esports_match_options_single', 'artorias_core_add_esports_match_single_navigation_options' );
}
