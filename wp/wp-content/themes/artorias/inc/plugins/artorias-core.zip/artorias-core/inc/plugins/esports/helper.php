<?php

if ( ! function_exists( 'artorias_core_esports_set_admin_options_map_position' ) ) {
	/**
	 * Function that set dashboard admin options map position for this module
	 *
	 * @param int    $position
	 * @param string $map
	 *
	 * @return int
	 */
	function artorias_core_esports_set_admin_options_map_position( $position, $map ) {
		if ( 'esports' === $map ) {
			$position = 98;
		}

		return $position;
	}

	add_filter( 'artorias_core_filter_admin_options_map_position', 'artorias_core_esports_set_admin_options_map_position', 10, 2 );
}

if ( ! function_exists( 'artorias_core_esports_get_time_span' ) ) {
	/**
	 * Function that generates hours or minutes span
	 *
	 * @param $option
	 * @param $step
	 *
	 * @return array
	 */
	function artorias_core_esports_get_time_span( $option = 'hours', $step = 1 ) {
		$span     = array();
		$span[''] = esc_html__( 'N/A', 'artorias-core' );

		$span_start = 0;
		if ( 'hours' === $option ) {
			$span_end = 24;
		} elseif ( 'minutes' === $option ) {
			$span_end = 60;
		}

		for ( $i = $span_start; $i < $span_end; $i ++ ) {
			if ( ( $i % $step ) === 0 ) {
				$span[str_pad( $i, 2, '0', STR_PAD_LEFT )] = str_pad( $i, 2, '0', STR_PAD_LEFT );
			}
		}

		return $span;
	}
}

if ( ! function_exists( 'artorias_core_esports_get_team_logo_image_size' ) ) {
	/**
	 * Function that get predefined team logo size
	 *
	 * @return int
	 */
	function artorias_core_esports_get_team_logo_image_size( $team_single = false ) {
		if ( ! $team_single ) {
			$logo_image_size = 125;
		} else {
			$logo_image_size = 145;
		}

		return $logo_image_size;
	}
}
