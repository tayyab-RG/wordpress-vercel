<?php
$post_id       = get_the_ID();
$is_enabled    = artorias_core_get_post_value_through_levels( 'qodef_esports_match_single_enable_related_posts' );
$related_posts = artorias_core_get_custom_post_type_related_posts( $post_id, artorias_core_get_esports_match_single_post_taxonomies( $post_id ) );
?>
<?php if ( 'yes' === $is_enabled && ! empty( $related_posts ) && class_exists( 'ArtoriasCore_Esports_Match_List_Shortcode' ) ) : ?>
	<div id="qodef-esports-match-single-related-items">
		<?php
		$params = apply_filters(
			'artorias_core_filter_esports_match_single_related_posts_params',
			array(
				'custom_class'              => 'qodef--no-bottom-space',
				'columns'                   => 2,
				'posts_per_page'            => 2,
				'additional_params'         => 'id',
				'post_ids'                  => $related_posts['items'],
				'layout'                    => 'compact',
				'title_tag'                 => 'h5',
				'images_proportion'         => 'custom',
				'custom_image_width'        => 65,
				'custom_image_heigtt'       => 65,
				'compact_result_margin_top' => 80,
			)
		);

		echo ArtoriasCore_Esports_Match_List_Shortcode::call_shortcode( $params );
		?>
	</div>
<?php endif; ?>
