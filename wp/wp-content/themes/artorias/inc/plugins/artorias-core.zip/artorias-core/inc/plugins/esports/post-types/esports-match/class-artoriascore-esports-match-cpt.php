<?php

if ( ! function_exists( 'artorias_core_register_esports_match_for_meta_options' ) ) {
	/**
	 * Function that add custom post type into global meta box allowed items array for saving meta box options
	 *
	 * @param array $post_types
	 *
	 * @return array
	 */
	function artorias_core_register_esports_match_for_meta_options( $post_types ) {
		$post_types[] = 'esports-match';

		return $post_types;
	}

	add_filter( 'qode_framework_filter_meta_box_save', 'artorias_core_register_esports_match_for_meta_options' );
	add_filter( 'qode_framework_filter_meta_box_remove', 'artorias_core_register_esports_match_for_meta_options' );
}

if ( ! function_exists( 'artorias_core_add_esports_match_custom_post_type' ) ) {
	/**
	 * Function that adds esports match custom post type
	 *
	 * @param array $cpts
	 *
	 * @return array
	 */
	function artorias_core_add_esports_match_custom_post_type( $cpts ) {
		$cpts[] = 'ArtoriasCore_Esports_Match_CPT';

		return $cpts;
	}

	add_filter( 'artorias_core_filter_register_custom_post_types', 'artorias_core_add_esports_match_custom_post_type' );
}

if ( class_exists( 'QodeFrameworkCustomPostType' ) ) {
	class ArtoriasCore_Esports_Match_CPT extends QodeFrameworkCustomPostType {

		public function map_post_type() {
			$name = esc_html__( 'Esports Match', 'artorias-core' );
			$this->set_base( 'esports-match' );
			$this->set_menu_position( 10 );
			$this->set_menu_icon( QODE_FRAMEWORK_INC_URL_PATH . '/common/modules/admin/assets/img/admin-logo-icon.png' );
			$this->set_slug( 'esports-match' );
			$this->set_name( $name );
			$this->set_path( ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-match' );
			$this->set_labels(
				array(
					'name'          => esc_html__( 'Artorias Esports Match', 'artorias-core' ),
					'singular_name' => esc_html__( 'Esports Match', 'artorias-core' ),
					'add_item'      => esc_html__( 'New Esports Match', 'artorias-core' ),
					'add_new_item'  => esc_html__( 'Add New Esports Match', 'artorias-core' ),
					'edit_item'     => esc_html__( 'Edit Esports Match', 'artorias-core' ),
				)
			);
			$this->set_supports(
				array(
					'title',
					'editor',
					'thumbnail',
					'page-attributes',
					'comments',
				)
			);
			$this->add_post_taxonomy(
				array(
					'base'          => 'esports-match-game',
					'slug'          => 'esports-match-game',
					'singular_name' => esc_html__( 'Game', 'artorias-core' ),
					'plural_name'   => esc_html__( 'Games', 'artorias-core' ),
				)
			);
		}
	}
}
