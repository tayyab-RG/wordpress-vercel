<?php

if ( ! function_exists( 'artorias_core_add_esports_team_single_meta_box' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function artorias_core_add_esports_team_single_meta_box() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope'  => array( 'esports-team' ),
				'type'   => 'meta',
				'slug'   => 'esports-team',
				'title'  => esc_html__( 'Esports Team Settings', 'artorias-core' ),
				'layout' => 'tabbed',
			)
		);

		if ( $page ) {

			$general_tab = $page->add_tab_element(
				array(
					'name'        => 'tab-general',
					'icon'        => 'fa fa-cog',
					'title'       => esc_html__( 'General Settings', 'artorias-core' ),
					'description' => esc_html__( 'General esports team settings', 'artorias-core' ),
				)
			);

			$general_tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_esports_team_single_layout',
					'title'       => esc_html__( 'Single Layout', 'artorias-core' ),
					'description' => esc_html__( 'Choose default layout for esports team single', 'artorias-core' ),
					'options'     => apply_filters( 'artorias_core_filter_esports_team_single_layout_options', array( '' => esc_html__( 'Default', 'artorias-core' ) ) ),
				)
			);

			// Hook to include additional options before module options
			do_action( 'artorias_core_action_before_esports_team_meta_box_map', $page, $general_tab );

			$general_tab->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_esports_team_single_tagline',
					'title'      => esc_html__( 'Tagline', 'artorias-core' ),
				)
			);

			$section_team_players = $general_tab->add_section_element(
				array(
					'name'  => 'qodef_esports_team_players_section',
					'title' => esc_html__( 'Player Settings', 'artorias-core' ),
				)
			);

			$players_repeater = $section_team_players->add_repeater_element(
				array(
					'name'        => 'qodef_esports_team_players',
					'title'       => esc_html__( 'Players', 'artorias-core' ),
					'description' => esc_html__( 'Enter players for this team', 'artorias-core' ),
					'button_text' => esc_html__( 'Add Player', 'artorias-core' ),
				)
			);

			$players_repeater->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_esports_team_player',
					'title'      => esc_html__( 'Team Player', 'artorias-core' ),
					'options'    => qode_framework_get_cpt_items(
						'esports-player',
						array(
							'numberposts' => '-1',
						)
					),
				)
			);

			$section_team_social_icons = $general_tab->add_section_element(
				array(
					'name'  => 'qodef_esports_team_social_icons_section',
					'title' => esc_html__( 'Social Networks Settings', 'artorias-core' ),
				)
			);

			$social_icons_repeater = $section_team_social_icons->add_repeater_element(
				array(
					'name'        => 'qodef_esports_team_social_icons',
					'title'       => esc_html__( 'Social Networks', 'artorias-core' ),
					'description' => esc_html__( 'Populate esports team social networks info', 'artorias-core' ),
					'button_text' => esc_html__( 'Add New Network', 'artorias-core' ),
				)
			);

			$social_icons_repeater->add_field_element(
				array(
					'field_type' => 'iconpack',
					'name'       => 'qodef_esport_team_icon',
					'title'      => esc_html__( 'Icon', 'artorias-core' ),
				)
			);

			$social_icons_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_esports_team_icon_link',
					'title'      => esc_html__( 'Link', 'artorias-core' ),
				)
			);

			$social_icons_repeater->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_esports_team_icon_target',
					'title'      => esc_html__( 'Target', 'artorias-core' ),
					'options'    => artorias_core_get_select_type_options_pool( 'link_target' ),
				)
			);

			$social_icons_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_esports_team_icon_label',
					'title'      => esc_html__( 'Label', 'artorias-core' ),
				)
			);

			$social_icons_repeater->add_field_element(
				array(
					'field_type' => 'image',
					'name'       => 'qodef_esports_team_icon_image',
					'title'      => esc_html__( 'Image', 'artorias-core' ),
				)
			);

			// Hook to include additional options after module options
			do_action( 'artorias_core_action_after_esports_team_meta_box_map', $page, $general_tab );
		}
	}

	add_action( 'artorias_core_action_default_meta_boxes_init', 'artorias_core_add_esports_team_single_meta_box' );
}

if ( ! function_exists( 'artorias_core_include_general_meta_boxes_for_esports_single' ) ) {
	/**
	 * Function that add general meta box options for this module
	 */
	function artorias_core_include_general_meta_boxes_for_esports_single() {
		$callbacks = artorias_core_general_meta_box_callbacks();

		if ( ! empty( $callbacks ) ) {
			foreach ( $callbacks as $module => $callback ) {

				if ( 'page-sidebar' !== $module ) {
					add_action( 'artorias_core_action_after_esports_single_meta_box_map', $callback );
				}
			}
		}
	}

	add_action( 'artorias_core_action_default_meta_boxes_init', 'artorias_core_include_general_meta_boxes_for_esports_single', 8 ); // Permission 8 is set in order to load it before default meta box function
}
