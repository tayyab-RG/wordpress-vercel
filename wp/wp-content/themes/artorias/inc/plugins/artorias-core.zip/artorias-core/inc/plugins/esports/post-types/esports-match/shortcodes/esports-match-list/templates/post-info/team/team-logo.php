<?php
$team_id           = get_post_meta( get_the_ID(), 'qodef_esports_match_single_team_' . $team, true );
$images_proportion = isset( $images_proportion ) ? $images_proportion : '';
$image_size        = 'custom' === $images_proportion ? array( $custom_image_width, $custom_image_height ) : $images_proportion;
$team_image        = get_the_post_thumbnail( $team_id, $image_size );
?>
<?php if ( $team_image ) : ?>
	<div class="qodef-e-team-logo">
		<a itemprop="url" class="qodef-e-team-name-link" href="<?php echo the_permalink( $team_id ); ?>">
			<?php echo qode_framework_wp_kses_html( 'html', $team_image ); ?>
		</a>
	</div>
<?php endif; ?>
