<?php
// Hook to include additional content before esports team single item
do_action( 'artorias_core_action_before_esports_team_single_item' );
?>
<article <?php post_class( 'qodef-esports-team-single qodef-variations--standard-full-width qodef-m' ); ?>>
	<div class="qodef-m-inner">
		<div class="qodef-m-content">
			<div class="qodef-content-grid qodef--width-exception">
				<div class="qodef-m-content-inner">
					<?php
					// Include post team label template
					artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/parts/post-info/team-label' );

					// Include post team tagline template
					artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/parts/post-info/team-tagline' );

					// Include post content template
					artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/parts/post-info/content' );
					?>
				</div>
				<?php
				// Include post team player list template
				artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/parts/post-info/team-player-list' );
				?>
			</div>
			<?php
			// Include post team social tabs template
			artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/parts/post-info/team-social-tabs' );
			?>
			<div class="qodef-content-grid qodef--width-exception">
				<?php
				// Include post social share template
				artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/parts/post-info/social-share' );
				?>
			</div>
		</div>
	</div>
</article>
<?php
// Hook to include additional content after esports team single item
do_action( 'artorias_core_action_after_esports_team_single_item' );
?>
