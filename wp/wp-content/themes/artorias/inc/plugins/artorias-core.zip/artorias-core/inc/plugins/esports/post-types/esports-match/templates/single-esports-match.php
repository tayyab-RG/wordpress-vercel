<?php

get_header();

// Include cpt content template
artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/content' );

get_footer();
