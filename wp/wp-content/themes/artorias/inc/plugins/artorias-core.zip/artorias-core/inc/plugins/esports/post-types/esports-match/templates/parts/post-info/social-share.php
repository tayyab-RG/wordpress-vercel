<?php
$social_share_enabled = 'yes' === artorias_core_get_post_value_through_levels( 'qodef_esports_match_enable_social_share' );
$social_share_layout  = artorias_core_get_post_value_through_levels( 'qodef_social_share_layout' );
?>
<?php if ( class_exists( 'ArtoriasCore_Social_Share_Shortcode' ) && $social_share_enabled ) : ?>
	<div class="qodef-m-social-share">
		<h5 class="qodef-m-social-share-label">
			<?php esc_html_e( 'Share: ', 'artorias-core' ); ?>
		</h5>
		<?php
		$params = array(
			'layout' => $social_share_layout,
		);

		echo ArtoriasCore_Social_Share_Shortcode::call_shortcode( $params );
		?>
	</div>
<?php endif; ?>
