<div class="qodef-grid-item <?php echo esc_attr( artorias_core_get_page_content_sidebar_classes() ); ?>">
	<div class="qodef-esports-team qodef-m <?php echo esc_attr( artorias_core_get_esports_team_holder_classes() ); ?>">
		<?php
		// Include esports team posts loop
		artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/parts/loop' );
		?>
	</div>
</div>
