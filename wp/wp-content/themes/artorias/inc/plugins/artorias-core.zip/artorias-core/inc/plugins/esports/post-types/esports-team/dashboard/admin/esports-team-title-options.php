<?php

if ( ! function_exists( 'artorias_core_add_esports_team_title_options' ) ) {
	/**
	 * Function that add title options for esports team module
	 */
	function artorias_core_add_esports_team_title_options( $tab ) {

		if ( $tab ) {

			$tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_enable_esports_team_title',
					'title'       => esc_html__( 'Enable Title on Esports Team Single', 'artorias-core' ),
					'description' => esc_html__( 'Use this option to enable/disable esports team single title', 'artorias-core' ),
					'options'     => artorias_core_get_select_type_options_pool( 'yes_no' ),
				)
			);

			$tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_set_esports_team_title_area_in_grid',
					'title'       => esc_html__( 'Esports Team Title in Grid', 'artorias-core' ),
					'description' => esc_html__( 'Enabling this option will set esports team title area to be in grid', 'artorias-core' ),
					'options'     => artorias_core_get_select_type_options_pool( 'yes_no' ),
				)
			);
		}
	}

	add_action( 'artorias_core_action_after_esports_team_options_single', 'artorias_core_add_esports_team_title_options' );
}
