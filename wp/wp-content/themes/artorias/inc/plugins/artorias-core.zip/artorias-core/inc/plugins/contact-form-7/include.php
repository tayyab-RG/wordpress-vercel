<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/contact-form-7/class-artoriascore-contact-form-7.php';
