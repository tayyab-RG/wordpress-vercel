<?php
$social_icons = get_post_meta( get_the_ID(), 'qodef_esports_team_social_icons', true );
?>
<?php if ( ! empty( $social_icons ) ) : ?>
	<?php
	$framework_icons = QodeFrameworkIcons::get_instance();
	?>
	<div class="qodef-e-social-icons">
		<?php if ( isset( $show_label ) && true === $show_label ): ?>
			<span class="qodef-e-social-label">
				<?php echo esc_html__( 'Watch: ', 'artorias-core' ); ?>
			</span>
		<?php endif; ?>
		<?php foreach ( $social_icons as $icon ) : ?>
			<?php if ( ! empty( $icon['qodef_esport_team_icon'] ) ) : ?>
				<?php
				$social_link      = $icon['qodef_esports_team_icon_link'];
				$social_target    = ! empty( $icon['qodef_esport_team_icon_target'] ) ? $icon['qodef_esport_team_icon_target'] : '_blank';
				$social_icon_pack = $icon['qodef_esport_team_icon'];
				$social_icon_name = $framework_icons->get_formatted_icon_field_name( 'qodef_esport_team_icon', $social_icon_pack, '-' );
				$social_icon      = $icon[$social_icon_name];
				?>
				<?php if ( ! empty( $social_icon ) ) : ?>
					<a class="qodef-e-social-icon" href="<?php echo esc_url( $social_link ); ?>" target="<?php echo esc_attr( $social_target ); ?>">
						<?php echo qode_framework_wp_kses_html( 'html', $framework_icons->render_icon( $social_icon, $social_icon_pack ) ); ?>
					</a>
				<?php endif; ?>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>
<?php endif; ?>
