<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-match/shortcodes/esports-match-list/widget/class-artoriascore-esports-match-simple-list-widget.php';
