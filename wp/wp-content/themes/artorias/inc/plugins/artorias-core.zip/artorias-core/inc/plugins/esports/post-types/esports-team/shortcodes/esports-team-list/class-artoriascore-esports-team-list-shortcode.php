<?php

if ( ! function_exists( 'artorias_core_add_esports_team_list_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function artorias_core_add_esports_team_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'ArtoriasCore_Esports_Team_List_Shortcode';

		return $shortcodes;
	}

	add_filter( 'artorias_core_filter_register_shortcodes', 'artorias_core_add_esports_team_list_shortcode' );
}

if ( class_exists( 'ArtoriasCore_List_Shortcode' ) ) {
	class ArtoriasCore_Esports_Team_List_Shortcode extends ArtoriasCore_List_Shortcode {

		public function __construct() {
			$this->set_post_type( 'esports-team' );
			$this->set_post_type_taxonomy( 'esports-team-game' );
			$this->set_layouts( apply_filters( 'artorias_core_filter_esports_team_list_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'artorias_core_filter_esports_team_list_extra_options', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( ARTORIAS_CORE_PLUGINS_URL_PATH . '/esports/post-types/esports-team/shortcodes/esports-team-list' );
			$this->set_base( 'artorias_core_esports_team_list' );
			$this->set_name( esc_html__( 'Esports Team List', 'artorias-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays list of esports teams', 'artorias-core' ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'artorias-core' ),
				)
			);
			$this->map_list_options();
			$this->map_query_options( array( 'post_type' => $this->get_post_type() ) );
			$this->map_layout_options(
				array(
					'layouts' => $this->get_layouts(),
				)
			);
            $this->set_option( array(
                'field_type'    => 'select',
                'name'          => 'enable_appear',
                'title'         => esc_html__( 'Enable Appear', 'artorias-core' ),
                'options'       => artorias_core_get_select_type_options_pool( 'yes_no', false ),
            ) );
			$this->map_additional_options();
			$this->map_extra_options();
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'artorias_core_esports_team_list', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function load_assets() {
			parent::load_assets();

			do_action( 'artorias_core_action_esports_team_list_load_assets', $this->get_atts() );
		}

		public function render( $options, $content = null ) {
			parent::render( $options );

			$atts = $this->get_atts();

			$atts['post_type']       = $this->get_post_type();
			$atts['taxonomy_filter'] = $this->get_post_type_filter_taxonomy( $atts );

			// Additional query args
			$atts['additional_query_args'] = $this->get_additional_query_args( $atts );

			$atts['query_result']   = new \WP_Query( artorias_core_get_query_params( $atts ) );
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['slider_attr']    = $this->get_slider_data( $atts );
			$atts['data_attr']      = artorias_core_get_pagination_data( ARTORIAS_CORE_REL_PATH, 'plugins/esports/post-types/esports-team/shortcodes', 'esports-team-list', 'esports-team', $atts );

			$atts['this_shortcode'] = $this;

			return artorias_core_get_template_part( 'plugins/esports/post-types/esports-team/shortcodes/esports-team-list', 'templates/content', $atts['behavior'], $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-esports-team-list';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-item-layout--' . $atts['layout'] : '';
            $holder_classes[] = ( 'yes' === $atts['enable_appear'] ) ? 'qodef--has-appear': '';

			$list_classes   = $this->get_list_classes( $atts );
			$holder_classes = array_merge( $holder_classes, $list_classes );

			return implode( ' ', $holder_classes );
		}

		public function get_item_classes( $atts ) {
			$item_classes = $this->init_item_classes();

			$list_item_classes = $this->get_list_item_classes( $atts );

			$item_classes = array_merge( $item_classes, $list_item_classes );

			return implode( ' ', $item_classes );
		}

		public function get_title_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['text_transform'];
			}

			return $styles;
		}

		public function get_inner_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['minimal_gap'] ) ) {
				$gap      = qode_framework_string_ends_with_space_units( $atts['minimal_gap'] ) ? $atts['minimal_gap'] : intval( $atts['minimal_gap'] ) . 'px';
				$styles[] = 'row-gap:' . $gap;
				$styles[] = 'column-gap:' . $gap;
			}

			return $styles;
		}
	}
}
