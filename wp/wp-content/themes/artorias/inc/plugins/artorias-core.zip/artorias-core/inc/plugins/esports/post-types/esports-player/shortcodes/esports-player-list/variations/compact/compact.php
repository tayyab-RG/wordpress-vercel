<?php

if ( ! function_exists( 'artorias_core_add_esports_player_list_variation_compact' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function artorias_core_add_esports_player_list_variation_compact( $variations ) {
		$variations['compact'] = esc_html__( 'Compact', 'artorias-core' );

		return $variations;
	}

	add_filter( 'artorias_core_filter_esports_player_list_layouts', 'artorias_core_add_esports_player_list_variation_compact' );
}
