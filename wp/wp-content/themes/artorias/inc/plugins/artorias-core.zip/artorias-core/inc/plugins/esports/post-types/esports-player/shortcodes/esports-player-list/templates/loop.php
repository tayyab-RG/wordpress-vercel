<?php if ( $query_result->have_posts() ): ?>
	<?php while ( $query_result->have_posts() ) : ?>
		<?php
		$query_result->the_post();

		$params['image_dimension'] = $this_shortcode->get_list_item_image_dimension( $params );
		$params['item_classes']    = $this_shortcode->get_item_classes( $params );

		// Include layout template
		artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-player/shortcodes/esports-player-list', 'layouts/' . $layout, '', $params );
		?>
	<?php endwhile; ?>
<?php else: ?>
	<?php
	// Include global posts not found template
	artorias_core_theme_template_part( 'content', 'templates/parts/posts-not-found' );
	?>
<?php endif; ?>
<?php wp_reset_postdata(); ?>
