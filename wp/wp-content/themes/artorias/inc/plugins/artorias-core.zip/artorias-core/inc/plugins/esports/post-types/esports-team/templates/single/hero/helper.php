<?php

if ( ! function_exists( 'artorias_core_include_esports_team_single_hero_template' ) ) {
	/**
	 * Function which includes additional module on single esports match page
	 */
	function artorias_core_include_esports_team_single_hero_template() {
		if ( ! is_archive() ) {
			artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/single/hero/templates/hero' );
		}
	}

	add_action( 'artorias_core_action_before_esports_team_content_holder', 'artorias_core_include_esports_team_single_hero_template' );
}
