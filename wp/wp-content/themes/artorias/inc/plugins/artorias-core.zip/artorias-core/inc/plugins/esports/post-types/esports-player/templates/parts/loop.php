<?php if ( have_posts() ) : ?>
	<?php while ( have_posts() ) : ?>
		<?php the_post(); ?>
		<?php
		// Hook to include additional content before post item
		do_action( 'artorias_core_action_before_esports_player_item' );

		$item_layout = apply_filters( 'artorias_core_filter_esports_player_single_layout', '' );

		// Include post layout template
		artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'variations/' . $item_layout . '/layout/' . $item_layout );

		// Hook to include additional content after post item
		do_action( 'artorias_core_action_after_esports_player_item' );
		?>
	<?php endwhile; ?>
<?php else: ?>
	<?php
	// Include global posts not found
	artorias_core_theme_template_part( 'content', 'templates/parts/posts-not-found' );
	?>
<?php endif; ?>
<?php wp_reset_postdata(); ?>
