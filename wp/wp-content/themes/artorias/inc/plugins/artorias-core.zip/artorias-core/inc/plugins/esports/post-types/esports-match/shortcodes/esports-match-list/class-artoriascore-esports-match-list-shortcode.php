<?php

if ( ! function_exists( 'artorias_core_add_esports_match_list_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function artorias_core_add_esports_match_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'ArtoriasCore_Esports_Match_List_Shortcode';

		return $shortcodes;
	}

	add_filter( 'artorias_core_filter_register_shortcodes', 'artorias_core_add_esports_match_list_shortcode' );
}

if ( class_exists( 'ArtoriasCore_List_Shortcode' ) ) {
	class ArtoriasCore_Esports_Match_List_Shortcode extends ArtoriasCore_List_Shortcode {

		public function __construct() {
			$this->set_post_type( 'esports-match' );
			$this->set_post_type_taxonomy( 'esports-match-game' );
			$this->set_layouts( apply_filters( 'artorias_core_filter_esports_match_list_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'artorias_core_filter_esports_match_list_extra_options', array() ) );

			add_filter( 'artorias_core_filter_map_additional_query_params', array( $this, 'add_additional_query_params' ), 10, 2 );
			add_action( 'artorias_core_action_map_query_options_after_additional', array( $this, 'add_additional_query_fields' ) );
			add_filter( 'artorias_core_filter_additional_query_args', array( $this, 'additional_query' ), 10, 3 );

			parent::__construct();
		}

		public function add_additional_query_params( $params, $base ) {
			if ( 'artorias_core_esports_match_list' === $base ) {
				$params['team-and-status'] = esc_html__( 'Team And Status', 'artorias-core' );
			}

			return $params;
		}

		public function add_additional_query_fields( $group ) {
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'team',
					'title'      => esc_html__( 'Team', 'artorias-core' ),
					'options'    => array_merge(
						qode_framework_get_cpt_items(
							'esports-team',
							array(
								'numberposts' => '-1',
							),
							true
						), array(
							'current' => esc_html__( 'Current Team', 'artorias-core' ),
						)
					),
					'group'      => $group,
					'dependency' => array(
						'show' => array(
							'additional_params' => array(
								'values'        => 'team-and-status',
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'status',
					'title'      => esc_html__( 'Status', 'artorias-core' ),
					'options'    => artorias_core_get_esports_match_status( '', true ),
					'group'      => $group,
					'dependency' => array(
						'show' => array(
							'additional_params' => array(
								'values'        => 'team-and-status',
								'default_value' => '',
							),
						),
					),
				)
			);
            $this->set_option( array(
                'field_type'    => 'select',
                'name'          => 'enable_appear',
                'title'         => esc_html__( 'Enable Appear', 'artorias-core' ),
                'options'       => artorias_core_get_select_type_options_pool( 'yes_no', false ),
                'dependency' => array(
                    'show' => array(
                        'layout' => array(
                            'values'        => 'full-details',
                            'default_value' => '',
                        ),
                    ),
                ),
            ) );
		}

		public function additional_query( $args, $atts, $post_type ) {
			if ( $post_type === $this->get_post_type() ) {
				if ( ! empty( $atts['additional_params'] ) && 'team-and-status' === $atts['additional_params'] ) {
					$team   = ! empty( $atts['team'] ) && 'current' == $atts['team'] ? get_the_ID() : $atts['team'];
					$status = $atts['status'];

					if ( ! empty( $team ) && ! empty( $status ) ) {
						$args['meta_query'] = array(
							'relation' => 'AND',
							array(
								'relation' => 'OR',
								array(
									'key'     => 'qodef_esports_match_single_team_one',
									'value'   => $team,
									'compare' => '=',
								),
								array(
									'key'     => 'qodef_esports_match_single_team_two',
									'value'   => $team,
									'compare' => '=',
								),
							),
							array(
								'key'     => 'qodef_esports_match_single_status',
								'value'   => $status,
								'compare' => '=',
							),
						);
					} elseif ( ! empty( $team ) ) {
						$args['meta_query'] = array(
							'relation' => 'OR',
							array(
								'key'     => 'qodef_esports_match_single_team_one',
								'value'   => $team,
								'compare' => '=',
							),
							array(
								'key'     => 'qodef_esports_match_single_team_two',
								'value'   => $team,
								'compare' => '=',
							),
						);
					} elseif ( ! empty( $status ) ) {
						$args['meta_query'] = array(
							array(
								'key'     => 'qodef_esports_match_single_status',
								'value'   => $status,
								'compare' => '=',
							),
						);
					}
				}
			}

			return $args;
		}

		public function map_shortcode() {
			$this->set_shortcode_path( ARTORIAS_CORE_PLUGINS_URL_PATH . '/esports/post-types/esports-match/shortcodes/esports-match-list' );
			$this->set_base( 'artorias_core_esports_match_list' );
			$this->set_name( esc_html__( 'Esports Match List', 'artorias-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays list of esports matches', 'artorias-core' ) );
			$this->set_scripts( apply_filters( 'artorias_core_filter_esports_match_list_register_assets', array() ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'artorias-core' ),
				)
			);
			$this->map_list_options(
				array(
					'include_slider_option' => array(
						'slider_hidden_slides',
					),
				)
			);
			$this->map_query_options( array( 'post_type' => $this->get_post_type() ) );
			$this->map_layout_options(
				array(
					'layouts' => $this->get_layouts(),
				)
			);
			$this->map_additional_options();
			$this->map_extra_options();
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'artorias_core_esports_match_list', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function load_assets() {
			parent::load_assets();

			do_action( 'artorias_core_action_esports_match_list_load_assets', $this->get_atts() );
		}

		public function render( $options, $content = null ) {
			parent::render( $options );

			$atts = $this->get_atts();

			$atts['post_type']       = $this->get_post_type();
			$atts['taxonomy_filter'] = $this->get_post_type_filter_taxonomy( $atts );
			$atts['result_styles']   = $this->get_result_styles( $atts );

			// Additional query args
			$atts['additional_query_args'] = $this->get_additional_query_args( $atts );

			$atts['query_result']   = new \WP_Query( artorias_core_get_query_params( $atts ) );
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['slider_attr']    = $this->get_slider_data( $atts );
			$atts['data_attr']      = artorias_core_get_pagination_data( ARTORIAS_CORE_REL_PATH, 'plugins/esports/post-types/esports-match/shortcodes', 'esports-match-list', 'esports-match', $atts );

			$atts['this_shortcode'] = $this;

			return artorias_core_get_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'templates/content', $atts['behavior'], $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-esports-match-list';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-item-layout--' . $atts['layout'] : '';
            $holder_classes[] = ( 'yes' === $atts['enable_appear'] ) ? 'qodef--has-appear': '';

			$list_classes            = $this->get_list_classes( $atts );
			$hover_animation_classes = $this->get_hover_animation_classes( $atts );
			$holder_classes          = array_merge( $holder_classes, $list_classes, $hover_animation_classes );

			return implode( ' ', $holder_classes );
		}

		public function get_item_classes( $atts ) {
			$item_classes = $this->init_item_classes();

            $item_classes[] = ( 'yes' === $atts['enable_appear'] ) ? 'qodef--has-appear': '';

            $list_item_classes = $this->get_list_item_classes( $atts );

			$item_classes = array_merge( $item_classes, $list_item_classes );

			return implode( ' ', $item_classes );
		}

		public function get_title_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['text_transform'];
			}

			return $styles;
		}

		public function get_result_styles( $atts ) {
			$styles                    = array();
			$compact_result_margin_top = $atts['compact_result_margin_top'];

			if ( ! empty( $compact_result_margin_top ) ) {
				$margin_top = qode_framework_string_ends_with_space_units( $compact_result_margin_top ) ? $compact_result_margin_top : intval( $compact_result_margin_top ) . 'px';
				$styles[]   = 'margin-top:' . $margin_top;
			}

			return $styles;
		}
	}
}
