<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<div class="qodef-e-team qodef--team-one">
			<?php
			// Include post team 1 logo template
			artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/team/team-logo', '', array_merge( $params, array( 'team' => 'one' ) ) );
			?>
		</div>
		<div class="qodef-e-meta">
			<div class="qodef-e-result">
				<?php
				// Include post match result template
				artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/match-result', '', $params );
				?>
			</div>
			<div class="qodef-e-match-info qodef-e-info">
				<?php
				// Include post match date/time template
				artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/match-date-time' );
				?>
			</div>
		</div>
		<div class="qodef-e-team qodef--team-two">
			<?php
			// Include post team 2 logo template
			artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/team/team-logo', '', array_merge( $params, array( 'team' => 'two' ) ) );
			?>
		</div>
	</div>
</article>
