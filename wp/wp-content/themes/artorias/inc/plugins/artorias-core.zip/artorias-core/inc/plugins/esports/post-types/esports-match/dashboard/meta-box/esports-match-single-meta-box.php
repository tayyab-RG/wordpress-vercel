<?php

if ( ! function_exists( 'artorias_core_add_esports_match_single_meta_box' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function artorias_core_add_esports_match_single_meta_box() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope'  => array( 'esports-match' ),
				'type'   => 'meta',
				'slug'   => 'esports-match',
				'title'  => esc_html__( 'Esports Match Settings', 'artorias-core' ),
				'layout' => 'tabbed',
			)
		);

		if ( $page ) {

			$general_tab = $page->add_tab_element(
				array(
					'name'        => 'tab-general',
					'icon'        => 'fa fa-cog',
					'title'       => esc_html__( 'General Settings', 'artorias-core' ),
					'description' => esc_html__( 'General esports match settings', 'artorias-core' ),
				)
			);

			$general_tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_esports_match_single_layout',
					'title'       => esc_html__( 'Single Layout', 'artorias-core' ),
					'description' => esc_html__( 'Choose default layout for esports match single', 'artorias-core' ),
					'options'     => apply_filters( 'artorias_core_filter_esports_match_single_layout_options', array( '' => esc_html__( 'Default', 'artorias-core' ) ) ),
				)
			);

			// Hook to include additional options before module options
			do_action( 'artorias_core_action_before_esports_match_meta_box_map', $page, $general_tab );

			$section_match_details = $general_tab->add_section_element(
				array(
					'name'  => 'qodef_esports_game_details_section',
					'title' => esc_html__( 'Game Details Settings', 'artorias-core' ),
				)
			);

			$date_time_row = $section_match_details->add_row_element(
				array(
					'name' => 'qodef_esports_match_single_date_time_row',
				)
			);

			$date_time_row->add_field_element(
				array(
					'field_type' => 'date',
					'name'       => 'qodef_esports_match_single_date',
					'title'      => esc_html__( 'Date', 'artorias-core' ),
					'args'       => array(
						'col_width' => 3,
					),
				)
			);

			$date_time_row->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_esports_match_single_hour',
					'title'      => esc_html__( 'Hour', 'artorias-core' ),
					'options'    => artorias_core_esports_get_time_span(),
					'args'       => array(
						'col_width' => 3,
					),
				)
			);

			$date_time_row->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_esports_match_single_minute',
					'title'      => esc_html__( 'Minute', 'artorias-core' ),
					'options'    => artorias_core_esports_get_time_span( 'minutes', 5 ),
					'args'       => array(
						'col_width' => 3,
					),
				)
			);

			$teams_row = $section_match_details->add_row_element(
				array(
					'name' => 'qodef_eposts_match_single_teams_row',
				)
			);

			$teams_row->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_esports_match_single_team_one',
					'title'      => esc_html__( 'Team One', 'artorias-core' ),
					'options'    => qode_framework_get_cpt_items(
						'esports-team',
						array(
							'numberposts' => '-1',
						)
					),
					'args'       => array(
						'col_width' => 3,
					),
				)
			);

			$teams_row->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_esports_match_single_team_two',
					'title'      => esc_html__( 'Team Two', 'artorias-core' ),
					'options'    => qode_framework_get_cpt_items(
						'esports-team',
						array(
							'numberposts' => '-1',
						)
					),
					'args'       => array(
						'col_width' => 3,
					),
				)
			);

			$results_row = $section_match_details->add_row_element(
				array(
					'name' => 'qodef_esports_match_single_results_row',
				)
			);

			$results_row->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_esports_match_single_result',
					'title'      => esc_html__( 'Result', 'artorias-core' ),
					'args'       => array(
						'col_width' => 3,
					),
				),
			);

			$results_row->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_esports_match_single_status',
					'title'      => esc_html__( 'Status', 'artorias-core' ),
					'options'    => artorias_core_get_esports_match_status(),
					'args'       => array(
						'col_width' => 3,
					),
				),
			);

			// Hook to include additional options after module options
			do_action( 'artorias_core_action_after_esports_match_meta_box_map', $page, $general_tab );
		}
	}

	add_action( 'artorias_core_action_default_meta_boxes_init', 'artorias_core_add_esports_match_single_meta_box' );
}

if ( ! function_exists( 'artorias_core_include_general_meta_boxes_for_esports_single' ) ) {
	/**
	 * Function that add general meta box options for this module
	 */
	function artorias_core_include_general_meta_boxes_for_esports_single() {
		$callbacks = artorias_core_general_meta_box_callbacks();

		if ( ! empty( $callbacks ) ) {
			foreach ( $callbacks as $module => $callback ) {

				if ( 'page-sidebar' !== $module ) {
					add_action( 'artorias_core_action_after_esports_single_meta_box_map', $callback );
				}
			}
		}
	}

	add_action( 'artorias_core_action_default_meta_boxes_init', 'artorias_core_include_general_meta_boxes_for_esports_single', 8 ); // Permission 8 is set in order to load it before default meta box function
}
