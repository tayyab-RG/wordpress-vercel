<?php

// if ( ! function_exists( 'artorias_core_enqueue_esports_team_assets' ) ) {
// 	/**
// 	 * Function that enqueue 3rd party plugins script
// 	 */
// 	function artorias_core_enqueue_esports_team_assets() {
//
// 		if ( is_singular( 'esports-team' ) ) {
// 			wp_enqueue_style( 'magnific-popup' );
// 			wp_enqueue_script( 'jquery-magnific-popup' );
// 		}
// 	}
//
// 	add_action( 'artorias_core_action_before_main_css', 'artorias_core_enqueue_esports_team_assets' );
// }

if ( ! function_exists( 'artorias_core_generate_esports_team_single_layout' ) ) {
	/**
	 * Function that return default layout for custom post type single page
	 *
	 * @return string
	 */
	function artorias_core_generate_esports_team_single_layout() {
		$esports_team_template = artorias_core_get_post_value_through_levels( 'qodef_esports_team_single_layout' );
		$esports_team_template = ! empty( $esports_team_template ) ? $esports_team_template : '';

		return $esports_team_template;
	}

	add_filter( 'artorias_core_filter_esports_team_single_layout', 'artorias_core_generate_esports_team_single_layout' );
}

if ( ! function_exists( 'artorias_core_get_esports_team_holder_classes' ) ) {
	/**
	 * Function that return classes for the main esports team holder
	 *
	 * @return string
	 */
	function artorias_core_get_esports_team_holder_classes() {
		$classes = array( 'qodef-esports-team' );

		$item_layout = artorias_core_generate_esports_team_single_layout();
		if ( ! empty( $item_layout ) ) {
			$classes[] = 'qodef-layout--' . $item_layout;
		}

		return implode( ' ', $classes );
	}
}

if ( ! function_exists( 'artorias_core_set_esports_team_single_body_classes' ) ) {
	/**
	 * Function that add additional class name into global class list for body tag
	 *
	 * @param array $classes
	 *
	 * @return array
	 */
	function artorias_core_set_esports_team_single_body_classes( $classes ) {
		$item_layout = artorias_core_get_post_value_through_levels( 'qodef_esports_team_single_layout' );

		if ( is_singular( 'esports-team' ) && ! empty( $item_layout ) ) {
			$classes[] = 'qodef-layout--' . $item_layout;
		}

		return $classes;
	}

	add_filter( 'body_class', 'artorias_core_set_esports_team_single_body_classes' );
}

if ( ! function_exists( 'artorias_core_set_esports_team_single_page_inner_classes' ) ) {
	/**
	 * Function that set fake full width layout for esports team single layouts
	 *
	 * @return string|void
	 */
	function artorias_core_set_esports_team_single_page_inner_classes( $classes ) {
		$item_layout        = artorias_core_get_post_value_through_levels( 'qodef_esports_team_single_layout' );
		$full_width_layouts = apply_filters( 'artorias_core_filter_esports_team_single_full_width_layouts', array() );

		if ( is_singular( 'esports-team' ) && ! empty( $item_layout ) ) {
			foreach ( $full_width_layouts as $full_width_layout ) {
				if ( $item_layout === $full_width_layout ) {
					$classes = 'qodef-content-full-width';
				}
			}
		}

		return $classes;
	}

	add_filter( 'artorias_filter_page_inner_classes', 'artorias_core_set_esports_team_single_page_inner_classes' );
}

if ( ! function_exists( 'artorias_core_generate_esports_team_archive_with_shortcode' ) ) {
	/**
	 * Function that executes esports team list shortcode with params on archive pages
	 *
	 * @param string $tax      - type of taxonomy
	 * @param string $tax_slug - slug of taxonomy
	 */
	function artorias_core_generate_esports_team_archive_with_shortcode( $tax, $tax_slug ) {
		$params = array();

		$params['additional_params'] = 'tax';
		$params['tax']               = $tax;
		$params['tax_slug']          = $tax_slug;
		$params['columns']           = 3;
		$params['posts_per_page']    = 12;
		$params['pagination_type']   = 'standard';

		echo ArtoriasCore_Esports_Team_List_Shortcode::call_shortcode( $params );
	}
}

if ( ! function_exists( 'artorias_core_is_esports_team_title_enabled' ) ) {
	/**
	 * Function that check is module enabled
	 *
	 * @param bool $is_enabled
	 *
	 * @return bool
	 */
	function artorias_core_is_esports_team_title_enabled( $is_enabled ) {

		if ( is_singular( 'esports-team' ) ) {
			$esports_team_title = artorias_core_get_post_value_through_levels( 'qodef_enable_esports_team_title' );
			$is_enabled         = '' === $esports_team_title ? $is_enabled : ( 'no' === $esports_team_title ? false : true );
		}

		return $is_enabled;
	}

	add_filter( 'artorias_core_filter_is_page_title_enabled', 'artorias_core_is_esports_team_title_enabled' );
}

if ( ! function_exists( 'artorias_core_esports_team_title_grid' ) ) {
	/**
	 * Function that check is option enabled
	 *
	 * @param bool $enable_title_grid
	 *
	 * @return bool
	 */
	function artorias_core_esports_team_title_grid( $enable_title_grid ) {
		if ( is_singular( 'esports-team' ) ) {
			$esports_team_title_grid = artorias_core_get_post_value_through_levels( 'qodef_set_esports_team_title_area_in_grid' );
			$enable_title_grid       = '' === $esports_team_title_grid ? $enable_title_grid : ( 'no' === $esports_team_title_grid ? false : true );
		}

		return $enable_title_grid;
	}

	add_filter( 'artorias_core_filter_page_title_in_grid', 'artorias_core_esports_team_title_grid' );
}

if ( ! function_exists( 'artorias_core_esports_team_breadcrumbs_title' ) ) {
	/**
	 * Improve main breadcrumbs template with additional cases
	 *
	 * @param string|html $wrap_child
	 * @param array       $settings
	 *
	 * @return string|html
	 */
	function artorias_core_esports_team_breadcrumbs_title( $wrap_child, $settings ) {
		if ( is_tax( 'esports-team-game' ) ) {
			$wrap_child  = '';
			$term_object = get_term( get_queried_object_id(), 'esports-team-game' );

			if ( isset( $term_object->parent ) && 0 !== $term_object->parent ) {
				$parent     = get_term( $term_object->parent );
				$wrap_child .= sprintf( $settings['link'], get_term_link( $parent->term_id ), $parent->name ) . $settings['separator'];
			}

			$wrap_child .= sprintf( $settings['current_item'], single_cat_title( '', false ) );

		} elseif ( is_singular( 'esports-team' ) ) {
			$wrap_child = '';
			$post_terms = wp_get_post_terms( get_the_ID(), 'esports-team-game' );

			if ( ! empty( $post_terms ) ) {
				$post_term = $post_terms[0];
				if ( isset( $post_term->parent ) && 0 !== $post_term->parent ) {
					$parent     = get_term( $post_term->parent );
					$wrap_child .= sprintf( $settings['link'], get_term_link( $parent->term_id ), $parent->name ) . $settings['separator'];
				}
				$wrap_child .= sprintf( $settings['link'], get_term_link( $post_term ), $post_term->name ) . $settings['separator'];
			}

			$wrap_child .= sprintf( $settings['current_item'], get_the_title() );
		}

		return $wrap_child;
	}

	add_filter( 'artorias_core_filter_breadcrumbs_content', 'artorias_core_esports_team_breadcrumbs_title', 10, 2 );
}

if ( ! function_exists( 'artorias_core_set_esports_team_custom_sidebar_name' ) ) {
	/**
	 * Function that return sidebar name
	 *
	 * @param string $sidebar_name
	 *
	 * @return string
	 */
	function artorias_core_set_esports_team_custom_sidebar_name( $sidebar_name ) {

		if ( is_singular( 'esports-team' ) ) {
			$option = artorias_core_get_post_value_through_levels( 'qodef_esports_team_single_custom_sidebar' );
		} elseif ( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'esports-team' );

			foreach ( $taxonomies as $tax ) {
				if ( is_tax( $tax ) ) {
					$option = artorias_core_get_post_value_through_levels( 'qodef_page_custom_sidebar' );
				}
			}
		}

		if ( isset( $option ) && ! empty( $option ) ) {
			$sidebar_name = $option;
		}

		return $sidebar_name;
	}

	add_filter( 'artorias_filter_sidebar_name', 'artorias_core_set_esports_team_custom_sidebar_name' );
}

if ( ! function_exists( 'artorias_core_set_esports_team_sidebar_layout' ) ) {
	/**
	 * Function that return sidebar layout
	 *
	 * @param string $layout
	 *
	 * @return string
	 */
	function artorias_core_set_esports_team_sidebar_layout( $layout ) {

		if ( is_singular( 'esports-team' ) ) {
			$option = artorias_core_get_post_value_through_levels( 'qodef_esports_team_single_sidebar_layout' );
		} elseif ( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'esports-team' );
			foreach ( $taxonomies as $tax ) {
				if ( is_tax( $tax ) ) {
					$option = artorias_core_get_post_value_through_levels( 'qodef_page_sidebar_layout' );
				}
			}
		}

		if ( isset( $option ) && ! empty( $option ) ) {
			$layout = $option;
		}

		return $layout;
	}

	add_filter( 'artorias_filter_sidebar_layout', 'artorias_core_set_esports_team_sidebar_layout' );
}

if ( ! function_exists( 'artorias_core_set_esports_team_sidebar_grid_gutter_classes' ) ) {
	/**
	 * Function that returns grid gutter classes
	 *
	 * @param string $classes
	 *
	 * @return string
	 */
	function artorias_core_set_esports_team_sidebar_grid_gutter_classes( $classes ) {

		if ( is_singular( 'esports-team' ) ) {
			$option = artorias_core_get_post_value_through_levels( 'qodef_esports_team_single_sidebar_grid_gutter' );
		} elseif ( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'esports-team' );
			foreach ( $taxonomies as $tax ) {
				if ( is_tax( $tax ) ) {
					$option = artorias_core_get_post_value_through_levels( 'qodef_page_sidebar_grid_gutter' );
				}
			}
		}
		if ( isset( $option ) && ! empty( $option ) ) {
			$classes = 'qodef-gutter--' . esc_attr( $option );
		}

		return $classes;
	}

	add_filter( 'artorias_filter_grid_gutter_classes', 'artorias_core_set_esports_team_sidebar_grid_gutter_classes' );
}

if ( ! function_exists( 'artorias_core_get_esports_team_single_post_taxonomies' ) ) {
	/**
	 * Function that return single post taxonomies list
	 *
	 * @param int $post_id
	 *
	 * @return array
	 */
	function artorias_core_get_esports_team_single_post_taxonomies( $post_id ) {
		$options = array();

		if ( ! empty( $post_id ) ) {
			$options['esports-team-game'] = wp_get_post_terms( $post_id, 'esports-team-game' );
		}

		return $options;
	}
}
