(function ($) {
	"use strict";

	$(window).on('load', function () {
		qodefStickyColumn.init('init');
	});

	$(window).resize(function () {
		qodefStickyColumn.init('resize');
	});

	var qodefStickyColumn = {
		pageOffset  : '',
		scrollAmount: '',

		init                : function (state) {
			var $holder = $('.qodef-sticky-column'),
				editor = $holder.hasClass('wpb_column') ? 'wp_bakery' : 'elementor';

			if ($holder.length) {
				$holder.each(function () {
					qodefStickyColumn.calculateVars($(this), state, editor);
				});
			}
		},
		calculateVars       : function ($column, state, editor) {
			var columnVars = {};

			if ('wp_bakery' === editor) {
				columnVars.$columnInner = $column.find('.vc_column-inner').first();
			} else {
				columnVars.$columnInner = $column.find('.elementor-widget-wrap').first();
			}

			columnVars.columnTopEdgePosition = $column.offset().top;
			columnVars.columnLeftEdgePosition = $column.offset().left;
			columnVars.columnWidth = $column.outerWidth(true);
			columnVars.columnHeight = columnVars.$columnInner.outerHeight(true);

			if ('wp_bakery' === editor) {
				columnVars.$row = $column.closest('.vc_row');
			} else {
				columnVars.$row = $column.closest('.elementor-section');
			}

			columnVars.rowTopEdgePosition = columnVars.$row.offset().top;
			columnVars.rowHeight = columnVars.$row.outerHeight(true);
			columnVars.rowBottomEdgePosition = columnVars.rowTopEdgePosition + columnVars.rowHeight;
			qodefStickyColumn.scrollAmount = qodef.scroll;

			qodefStickyColumn.checkPosition(columnVars);

			$(window).scroll(function () {
				if ('init' === state) {
					var scrollDirection = qodefStickyColumn.checkScrollDirection();
				}

				qodefStickyColumn.checkPosition(columnVars, scrollDirection);
			});
		},
		checkPosition       : function (columnVars, direction) {
			if (qodef.windowWidth > 1024) {
				qodefStickyColumn.calculateOffset(columnVars);

				if ((qodef.scroll + qodefStickyColumn.pageOffset) <= columnVars.columnTopEdgePosition) {
					qodefStickyColumn.setPosition(columnVars, 'relative');
				}

				if (((qodef.scroll + qodefStickyColumn.pageOffset) >= columnVars.columnTopEdgePosition) && ((qodef.scroll + qodefStickyColumn.pageOffset + columnVars.columnHeight) < columnVars.rowBottomEdgePosition)) {
					qodefStickyColumn.setPosition(columnVars, 'fixed', direction);
				} else if ((qodef.scroll + qodefStickyColumn.pageOffset + columnVars.columnHeight) >= columnVars.rowBottomEdgePosition) {
					qodefStickyColumn.setPosition(columnVars, 'absolute');
				}
			} else {
				qodefStickyColumn.setPosition(columnVars, 'relative');
			}
		},
		calculateOffset     : function (columnVars) {
			qodefStickyColumn.pageOffset = 0;

			if(columnVars.$row.hasClass('qodef--aditional-sticky-offset') ){
				qodefStickyColumn.pageOffset += columnVars.rowTopEdgePosition;
			}

			if ($('body').hasClass('admin-bar')) {
				qodefStickyColumn.pageOffset += 32;
			}

			if ($('body').hasClass('qodef-header--sticky-display')) {
				qodefStickyColumn.pageOffset += parseInt($('.qodef-header-sticky').outerHeight(true));
			}

			if ($('body').hasClass('qodef-header--fixed-display')) {
				qodefStickyColumn.pageOffset += parseInt($('#qodef-page-header').outerHeight(true));
				qodefStickyColumn.pageOffset += parseInt($('#qodef-page-header').css('margin-top'));
			}
		},
		checkScrollDirection: function () {
			var scrollDirection = (qodef.scroll > qodefStickyColumn.scrollAmount) ? 'down' : 'up';

			qodefStickyColumn.scrollAmount = qodef.scroll;

			return scrollDirection;
		},
		setPosition         : function (columnVars, position, direction) {
			if ('relative' === position) {
				columnVars.$columnInner.css({
					'bottom'    : 'auto',
					'left'      : 'auto',
					'position'  : 'relative',
					'top'       : 'auto',
					'width'     : columnVars.columnWidth,
					'transform' : 'translateY(0)',
					'transition': 'none'
				});
			}

			if ('fixed' === position) {
				if ($('body').hasClass('qodef-header--sticky-display')) {
					var transitionValue = ('up' === direction) ? 'none' : 'transform .5s ease';
				}

				columnVars.$columnInner.css({
					'bottom'    : 'auto',
					'left'      : columnVars.columnLeftEdgePosition,
					'position'  : 'fixed',
					'top'       : 0,
					'width'     : columnVars.columnWidth,
					'transform' : 'translateY(' + qodefStickyColumn.pageOffset + 'px)',
					'transition': transitionValue
				});
			}

			if ('absolute' === position) {
				columnVars.$columnInner.css({
					'bottom'    : -columnVars.rowHeight,
					'left'      : '0',
					'position'  : 'absolute',
					'top'       : 'auto',
					'width'     : columnVars.columnWidth,
					'transform' : 'translateY(0)',
					'transition': 'none'
				});
			}
		}
	};

	window.qodefStickyColumn = qodefStickyColumn;
})(jQuery);
