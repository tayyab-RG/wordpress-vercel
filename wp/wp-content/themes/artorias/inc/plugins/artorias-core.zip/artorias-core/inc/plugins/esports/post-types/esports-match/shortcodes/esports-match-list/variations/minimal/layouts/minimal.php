<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<div class="qodef-e-team qodef--team-one">
			<?php
			// Include post team 1 logo template
			artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/team/team-logo', '', array_merge( $params, array( 'team' => 'one' ) ) );
			?>
			<div class="qodef-e-team-content">
				<?php
				// Include post team 1 name template
				artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/team/team-name', '', array_merge( $params, array( 'team' => 'one' ) ) );

				// Include post team 1 social icons template
				artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/team/team-social-icons', '', array( 'team' => 'one' ) );
				?>
			</div>
		</div>
		<div class="qodef-e-team qodef--team-two">
			<?php
			// Include post team 2 logo template
			artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/team/team-logo', '', array_merge( $params, array( 'team' => 'two' ) ) );
			?>
			<div class="qodef-e-team-content">
				<?php
				// Include post team 2 name template
				artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/team/team-name', '', array_merge( $params, array( 'team' => 'two' ) ) );

				// Include post team 2 social icons template
				artorias_core_list_sc_template_part( 'plugins/esports/post-types/esports-match/shortcodes/esports-match-list', 'post-info/team/team-social-icons', '', array( 'team' => 'two' ) );
				?>
			</div>
		</div>
	</div>
</article>
