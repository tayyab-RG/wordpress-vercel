<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-artoriascore-woocommerce-dropdown-cart-widget.php';
include_once ARTORIAS_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/helper.php';
