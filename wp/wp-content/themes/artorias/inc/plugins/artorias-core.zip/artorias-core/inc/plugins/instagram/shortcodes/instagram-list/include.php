<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/helper.php';
include_once ARTORIAS_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-artoriascore-instagram-list-shortcode.php';
