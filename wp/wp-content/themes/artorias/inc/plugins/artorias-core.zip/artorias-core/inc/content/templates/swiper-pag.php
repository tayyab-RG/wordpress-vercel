<?php if ( 'no' !== $slider_pagination ) { ?>
	<div class="swiper-pagination"></div>
<?php } ?>
