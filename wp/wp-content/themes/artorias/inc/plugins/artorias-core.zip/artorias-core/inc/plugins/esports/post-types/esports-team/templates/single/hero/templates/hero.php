<div id="qodef-esports-team-single-hero">
	<?php
	// Include post games template
	artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/single/hero/templates/parts/games' );

	// Include post image template
	artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/single/hero/templates/parts/image' );

	// Include post title template
	artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/single/hero/templates/parts/title' );

	// Include post hero background image template
	artorias_core_template_part( 'plugins/esports/post-types/esports-team', 'templates/single/hero/templates/parts/hero-background' );
	?>
</div>
