<?php
// Hook to include additional content before esports match single item
do_action( 'artorias_core_action_before_esports_match_single_item' );
?>
	<article <?php post_class( 'qodef-esports-match-single-item qodef-e' ); ?>>
		<div class="qodef-e-inner">
			<div class="qodef-e-content">
				<div class="qodef-grid-inner">
					<div class="qodef-grid-item qodef-esports-match-info">
						<?php artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/parts/post-info/content' ); ?>
					</div>
				</div>
			</div>
		</div>
	</article>
<?php
// Hook to include additional content after esports match single item
do_action( 'artorias_core_action_after_esports_match_single_item' );
?>
