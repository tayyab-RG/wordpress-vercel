<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-artoriascore-instagram-list-widget.php';
