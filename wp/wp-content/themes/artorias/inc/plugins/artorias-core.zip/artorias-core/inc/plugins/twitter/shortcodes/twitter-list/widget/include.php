<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/class-artoriascore-twitter-list-widget.php';
