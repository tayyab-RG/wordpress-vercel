<span class="qodef-m-label">
	<?php echo esc_html__( 'Players', 'artorias-core' ); ?>
</span>
