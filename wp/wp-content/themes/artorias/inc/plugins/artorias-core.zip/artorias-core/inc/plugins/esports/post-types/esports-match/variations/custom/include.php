<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-match/variations/custom/custom.php';
