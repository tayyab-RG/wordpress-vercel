<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-artoriascore-twitter-list-shortcode.php';
