<?php

if ( ! function_exists( 'artorias_core_add_esports_team_list_meta_boxes' ) ) {
	/**
	 * Function that add general meta box options for this module
	 *
	 * @param object $page
	 */
	function artorias_core_add_esports_team_list_meta_boxes( $page ) {

		if ( $page ) {

			$list_tab = $page->add_tab_element(
				array(
					'name'        => 'tab-list',
					'icon'        => 'fa fa-cog',
					'title'       => esc_html__( 'List Settings', 'artorias-core' ),
					'description' => esc_html__( 'Esports team list settings', 'artorias-core' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_esports_team_list_image',
					'title'       => esc_html__( 'Esports Team List Image', 'artorias-core' ),
					'description' => esc_html__( 'Upload image to be displayed on esports team list instead of featured image', 'artorias-core' ),
				)
			);

			$list_tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_masonry_image_dimension_esports_team_item',
					'title'       => esc_html__( 'Image Dimension', 'artorias-core' ),
					'description' => esc_html__( 'Choose an image layout for "masonry behavior" esports team list. If you are using fixed image proportions on the list, choose an option other than default', 'artorias-core' ),
					'options'     => artorias_core_get_select_type_options_pool( 'masonry_image_dimension' ),
				)
			);

			// Hook to include additional options after module options
			do_action( 'artorias_core_action_after_esports_team_list_meta_box_map', $list_tab );
		}
	}

	add_action( 'artorias_core_action_after_esports_team_meta_box_map', 'artorias_core_add_esports_team_list_meta_boxes' );
}

if ( ! function_exists( 'artorias_core_include_general_meta_boxes_for_esports_team_single' ) ) {
	/**
	 * Function that add general meta box options for this module
	 */
	function artorias_core_include_general_meta_boxes_for_esports_team_single() {
		$callbacks = artorias_core_general_meta_box_callbacks();

		if ( ! empty( $callbacks ) ) {
			foreach ( $callbacks as $module => $callback ) {

				if ( 'page-sidebar' !== $module ) {
					add_action( 'artorias_core_action_after_esports_team_meta_box_map', $callback );
				}
			}
		}
	}

	add_action( 'artorias_core_action_default_meta_boxes_init', 'artorias_core_include_general_meta_boxes_for_esports_team_single', 8 ); // Permission 8 is set in order to load it before default meta box function
}
