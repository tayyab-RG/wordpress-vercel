<?php
// Hook to include additional content before page content holder
do_action( 'artorias_core_action_before_esports_player_content_holder' );
?>
<main id="qodef-page-content" class="qodef-grid qodef-layout--template <?php echo esc_attr( artorias_core_get_grid_gutter_classes() ); ?>" role="main">
	<div class="qodef-grid-inner clear">
		<?php
		// Include esports player template
		$template_slug = isset( $template_slug ) ? $template_slug : '';
		artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/esports-player', $template_slug );

		// Include page content sidebar
		artorias_core_theme_template_part( 'sidebar', 'templates/sidebar' );
		?>
	</div>
</main>
<?php
// Hook to include additional content after main page content holder
do_action( 'artorias_core_action_after_esports_player_content_holder' );
?>
