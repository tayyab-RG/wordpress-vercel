<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-player/shortcodes/esports-player-list/variations/info-below/info-below.php';
