<?php
$team_role = get_post_meta( get_the_ID(), 'qodef_esports_player_single_team_role', true );
?>
<?php if ( ! empty( $team_role ) ): ?>
	<span class="qodef-e-team-role"><?php echo esc_html( $team_role ); ?></span>
<?php endif; ?>
