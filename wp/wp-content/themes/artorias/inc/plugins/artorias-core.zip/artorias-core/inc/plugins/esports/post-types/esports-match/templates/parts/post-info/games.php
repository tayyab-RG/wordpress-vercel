<?php
$games = wp_get_post_terms( get_the_ID(), 'esports-match-game' );
?>
<?php if ( ! empty( $games ) ) : ?>
	<div class="qodef-m-games">
		<?php echo get_the_term_list( get_the_ID(), 'esports-match-game', '', '<span class="qodef-info-separator-single"></span>' ); ?>
	</div>
	<div class="qodef-info-separator-end"></div>
<?php endif; ?>
