<?php


if ( ! function_exists( 'artorias_core_add_esports_player_options' ) ) {
	/**
	 * Function that add general options for this module
	 *
	 * @param object $page
	 */
	function artorias_core_add_esports_player_options( $page ) {

		if ( $page ) {

			$tab = $page->add_tab_element(
				array(
					'name'        => 'tab-esports-player',
					'icon'        => 'fa fa-cog',
					'title'       => esc_html__( 'Esports Player Single', 'artorias-core' ),
					'description' => esc_html__( 'Settings related to esports player single pages', 'artorias-core' ),
				)
			);

			$tab->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_esports_player_single_layout',
					'title'         => esc_html__( 'Single Layout', 'artorias-core' ),
					'description'   => esc_html__( 'Choose default layout for esports player single', 'artorias-core' ),
					'default_value' => apply_filters( 'artorias_core_filter_esports_player_single_layout_default_value', '' ),
					'options'       => apply_filters( 'artorias_core_filter_esports_player_single_layout_options', array() ),
				)
			);

			$tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_esports_player_single_title_tag',
					'title'       => esc_html__( 'Title Tag', 'artorias-core' ),
					'description' => esc_html__( 'Choose title tag for esport team on esports player page', 'artorias-core' ),
					'options'     => artorias_core_get_select_type_options_pool( 'title_tag' ),
				)
			);

			// Hook to include additional options after single module options
			do_action( 'artorias_core_action_after_esports_player_options_single', $tab );
		}
	}

	add_action( 'artorias_core_action_after_esports_options_map', 'artorias_core_add_esports_player_options' );
}
