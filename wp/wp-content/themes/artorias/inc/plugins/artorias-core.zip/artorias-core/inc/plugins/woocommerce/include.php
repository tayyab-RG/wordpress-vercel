<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/woocommerce/class-artoriascore-woocommerce.php';
