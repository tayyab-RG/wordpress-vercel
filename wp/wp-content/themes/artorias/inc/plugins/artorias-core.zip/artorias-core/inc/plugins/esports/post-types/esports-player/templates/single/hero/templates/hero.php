<div id="qodef-esports-player-single-hero">
	<?php
	// Include post title template
	artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/single/hero/templates/parts/title' );

	// Include post image template
	artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/single/hero/templates/parts/image' );

	// Include post hero background image template
	artorias_core_template_part( 'plugins/esports/post-types/esports-player', 'templates/single/hero/templates/parts/hero-background' ); ?>
</div>
