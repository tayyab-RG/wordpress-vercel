<?php

if ( ! function_exists( 'artorias_core_include_esports_match_single_related_posts_template' ) ) {
	/**
	 * Function which includes additional module on single esports match page
	 */
	function artorias_core_include_esports_match_single_related_posts_template() {
		artorias_core_template_part( 'plugins/esports/post-types/esports-match', 'templates/single/related-posts/templates/related-posts' );
	}

	add_action( 'artorias_core_action_after_esports_match_single_item', 'artorias_core_include_esports_match_single_related_posts_template', 20 ); // permission 20 is set to define template position
}
