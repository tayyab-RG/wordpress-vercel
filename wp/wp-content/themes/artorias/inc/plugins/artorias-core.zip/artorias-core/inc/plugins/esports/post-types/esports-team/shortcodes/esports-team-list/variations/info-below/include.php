<?php

include_once ARTORIAS_CORE_PLUGINS_PATH . '/esports/post-types/esports-team/shortcodes/esports-team-list/variations/info-below/info-below.php';
