<div class="qodef-m-action">
	<a itemprop="url" href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="qodef-m-action-link qodef-button qodef-layout--outlined qodef-size--full qodef-html--link">
		<?php esc_html_e( 'Cart & Checkout', 'artorias-core' ); ?>
	</a>
</div>
